package com.dxc.lmsapi.exception;
public class LibraryException extends Exception{

	public LibraryException(String message) {
		super(message);
	}
}
