create table books(
bcode integer primary key, 
bname varchar(20) not null, 
pdate date not null, 
price double  not null
);