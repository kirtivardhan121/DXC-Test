package com.dxc.ea.model;

public class EmployeeModel {

	private int employeeId;
	private String firstName;
	private String lastName;
	private double basicPay;

	private double houseRentAllow;
	private double travelAllowance;
	private double totalGrossSalary;

	public EmployeeModel() {
		// unimplemented
	}

	public EmployeeModel(int employeeId, String firstName, String lastName, double basicPay, double houseRentAllow,
			double travelAllowance, double totalGrossSalary) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.basicPay = basicPay;
		this.houseRentAllow = houseRentAllow;
		this.travelAllowance = travelAllowance;
		this.totalGrossSalary = totalGrossSalary;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public double getBasicPay() {
		return basicPay;
	}

	public void setBasicPay(double basicPay) {
		this.basicPay = basicPay;
	}

	public double getHouseRentAllow() {
		return houseRentAllow;
	}

	public void setHouseRentAllow(double houseRentAllow) {
		this.houseRentAllow = houseRentAllow;
	}

	public double getTravelAllowance() {
		return travelAllowance;
	}

	public void setTravelAllowance(double travelAllowance) {
		this.travelAllowance = travelAllowance;
	}

	public double getTotalGrossSalary() {
		return totalGrossSalary;
	}

	public void setTotalGrossSalary(double totalGrossSalary) {
		this.totalGrossSalary = totalGrossSalary;
	}
	
	
}
