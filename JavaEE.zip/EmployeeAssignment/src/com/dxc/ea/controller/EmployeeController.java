package com.dxc.ea.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dxc.ea.model.EmployeeModel;
import com.dxc.ea.service.EmployeeService;

/**
 * Servlet implementation class EmployeeController
 */
@WebServlet("/emp")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public EmployeeController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		EmployeeService service = new EmployeeService();

		String employeeId = request.getParameter("id");
		String firstName = request.getParameter("fname");
		String lastName = request.getParameter("lname");
		String basicPay = request.getParameter("bpay");

		String view = null;

		if (employeeId == null || firstName == null) {
			view = "/EmployeeInputPage.jsp";
		} else {

			EmployeeModel emp = new EmployeeModel();

			emp.setEmployeeId(Integer.parseInt(employeeId));
			emp.setFirstName(firstName);
			emp.setLastName(lastName);
			emp.setBasicPay(Double.parseDouble(basicPay));

			service.houseRentAllowance(emp);
			service.travelAllowance(emp);
			service.GrossSalary(emp);

			request.setAttribute("EmployeeSalary", emp);
			view = "/EmployeeOutputPage.jsp";

		}

		RequestDispatcher dispatcher = request.getRequestDispatcher(view);
		dispatcher.forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
