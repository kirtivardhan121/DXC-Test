package com.dxc.ea.service;

import com.dxc.ea.model.EmployeeModel;

public class EmployeeService {

	public void travelAllowance(EmployeeModel emp) {

		if (emp != null) {
			emp.setTravelAllowance((emp.getBasicPay() / 100) * 25);
		}
	}

	public void houseRentAllowance(EmployeeModel emp) {

		if (emp != null) {
			emp.setHouseRentAllow((emp.getBasicPay() / 100) * 45);

		}

	}

	public void GrossSalary(EmployeeModel emp) {

		if (emp != null) {
			emp.setTotalGrossSalary(emp.getBasicPay() + emp.getHouseRentAllow() + emp.getTravelAllowance());
		}
	}

}
