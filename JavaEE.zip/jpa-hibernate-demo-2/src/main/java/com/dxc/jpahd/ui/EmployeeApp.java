package com.dxc.jpahd.ui;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.dxc.jpahd.entity.ContractEmployee;
import com.dxc.jpahd.entity.Employee;
import com.dxc.jpahd.entity.Manager;

public class EmployeeApp {

	public static void main(String[] args) {
		
		Employee emp = new Employee(101L, "kirtivardhan", "singh", 26000.0, LocalDate.now());
		Manager mgr = new Manager(102L, "rajvardhan", "singh", 50000.0, LocalDate.now(), 5000.0);
		ContractEmployee cemp = new ContractEmployee(103L, "Yash", "vardhan", 80000.0, LocalDate.now(), 1);
		
		
			
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("mysqlPU");
		EntityManager em = emf.createEntityManager();
		
		EntityTransaction txn = em.getTransaction();
		
		txn.begin();
		
		em.persist(emp);
		em.persist(mgr);
		em.persist(cemp);
		
		txn.commit();
		em.close();
	}
}
