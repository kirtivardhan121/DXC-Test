package com.dxc.jpahd.ui;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.dxc.jpahd.entity.Employee;

public class EmployeeApp2 {

	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("mysqlPU");
		EntityManager em = emf.createEntityManager();
		
		Scanner kbScan = new Scanner(System.in);
		
		boolean shallContinue = true;
		
		while(shallContinue) {
			System.out.println("Enter Employee Id: ");
			long empid = kbScan.nextLong();
			
			Employee emp = em.find(Employee.class, empid);
			
			if(emp !=null) {
				System.out.println(emp.getFirstName() +" "+ emp.getLastNmae() +" "+ emp.getBasic() +" "+ emp.getJoinDate());
			} else {
				System.out.println("Emp Not found");
			}
			System.out.println("Continue? (true/false): ");
			
			shallContinue = kbScan.nextBoolean();
		}
		
		em.close();
	}
}
