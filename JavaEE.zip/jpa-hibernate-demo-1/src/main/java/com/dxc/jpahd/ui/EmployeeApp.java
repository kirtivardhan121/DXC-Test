package com.dxc.jpahd.ui;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.dxc.jpahd.entity.Employee;

public class EmployeeApp {

	public static void main(String[] args) {
		
		Employee[] emps = new Employee[] {
			new Employee(101L, "Kirti", "vardhan", 25000.0, LocalDate.now()),	
			new Employee(102L, "Raj", "vardhan", 50000.0, LocalDate.now()),
			new Employee(103L, "Harsh", "vardhan", 25000.0, LocalDate.now()),
			new Employee(104L, "Yash", "vardhan", 250000.0, LocalDate.now())
		};
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("mysqlPU");
		EntityManager em = emf.createEntityManager();
		
		EntityTransaction txn = em.getTransaction();
		
		txn.begin();
		
		for(Employee emp : emps) {
			em.persist(emp);
			System.out.println("Employee is saved!");
		}
		
		txn.commit();
		em.close();
	}
}
