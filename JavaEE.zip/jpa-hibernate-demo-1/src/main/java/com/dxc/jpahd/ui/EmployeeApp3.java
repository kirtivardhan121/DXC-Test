package com.dxc.jpahd.ui;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.dxc.jpahd.entity.Employee;

public class EmployeeApp3 {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("mysqlPU");
		EntityManager em = emf.createEntityManager();

		String qryText = "SELECT e FROM Employee e"; //JPQL

		//Query empQry = em.createQuery(qryText);

		TypedQuery<Employee> empQry = em.createQuery(qryText, Employee.class);

		List<Employee> emps = empQry.getResultList();

		for(Employee emp: emps) {
			System.out.println(emp.getFirstName() +"\t"+ emp.getLastNmae()+"\t"+emp.getBasic()+"\t"+emp.getJoinDate());
		}

		System.out.println("--------------------------------");
		
		TypedQuery<Employee> empQry2 = em.createQuery("SELECT e FROM Employee e WHERE e.basic between 25000 AND 50000", Employee.class);

		List<Employee> emps2 = empQry2.getResultList();

		for(Employee emp: emps2) {
			System.out.println(emp.getFirstName() +"\t"+ emp.getLastNmae()+"\t"+emp.getBasic()+"\t"+emp.getJoinDate());
		}
		
		System.out.println("---------------------------------");
		//Named Parameters
		TypedQuery<Employee> empQry3 = em.createQuery("SELECT e FROM Employee e WHERE e.basic between :limit1 and :limit2", Employee.class);

		empQry3.setParameter("limit1", 25000.0);
		empQry3.setParameter("limit2", 50000.0);
		
		List<Employee> emps3 = empQry2.getResultList();

		for(Employee emp: emps3) {
			System.out.println(emp.getFirstName() +"\t"+ emp.getLastNmae()+"\t"+emp.getBasic()+"\t"+emp.getJoinDate());
		}

		
		System.out.println("---------------------------------");
		//Named Queys
		
		TypedQuery<Employee> empQry4 = em.createNamedQuery("listEmpsWithLastName", Employee.class);
		
		empQry4.setParameter("lnm", "vardhan");
		
		List<Employee> emps4 = empQry4.getResultList();

		for(Employee emp: emps4) {
			System.out.println(emp.getFirstName() +"\t"+ emp.getLastNmae()+"\t"+emp.getBasic()+"\t"+emp.getJoinDate());
		}
		
		em.close();
	}
}
