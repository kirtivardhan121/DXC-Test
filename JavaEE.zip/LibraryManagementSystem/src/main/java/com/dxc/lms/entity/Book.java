package com.dxc.lms.entity;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PastOrPresent;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

@Entity
@Table(name = "books")
public class Book implements Serializable {

	@Id
	@Column(name = "bcode")
	@NotNull(message = "Book code can not be blank")
	private Integer bcode;
	
	@Column(name = "bname", nullable = false)
	@NotBlank(message = "Book name can not be blank")
	@Size(min = 4, max = 20, message = "BookName must be of 4 to 20 characters in length")
	private String bname;
	
	@Column(name = "price", nullable = false)
	@NotNull(message = "price can not be blank")
	@Min(value = 20, message = "minimum price is expected to be 100")
	@Max(value = 1000, message = "maximum price is expected not more than 2000")
	private double price;
	
	@Column(name = "pdate", nullable = true)
	@NotNull(message = "packageDate can not be blank")
	@PastOrPresent(message = "Package date can not be a future date")
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate packageDate;

	public Book() {
		// left unimplemented
	}

	public Book(int bcode, String bname, double price, LocalDate packageDate) {
		super();
		this.bcode = bcode;
		this.bname = bname;
		this.price = price;
		this.packageDate = packageDate;
	}

	public int getBcode() {
		return bcode;
	}

	public void setBcode(int bcode) {
		this.bcode = bcode;
	}

	public String getBname() {
		return bname;
	}

	public void setBname(String bname) {
		this.bname = bname;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public LocalDate getPackageDate() {
		return packageDate;
	}

	public void setPackageDate(LocalDate packageDate) {
		this.packageDate = packageDate;
	}

	@Override
	public String toString() {
		return "Book [bcode=" + bcode + ", bname=" + bname + ", price=" + price + ", packageDate=" + packageDate + "]";
	}

}
