package com.dxc.lms.service;

import java.time.LocalDate;
import java.util.List;

import com.dxc.lms.entity.Book;
import com.dxc.lms.exception.LibraryException;

public interface BookService {

	Book add(Book book) throws LibraryException;

	Book update(Book book) throws LibraryException;

	boolean deleteById(int bcode) throws LibraryException;

	Book getById(int bcode) throws LibraryException;

	List<Book> getAllBooks() throws LibraryException;

	Book findByBname(String bname) throws LibraryException;

	List<Book> findByPackageDate(LocalDate packageDate) throws LibraryException;

	List<Book> findByPriceRange(double lowerBound, double upperBound) throws LibraryException;
}
