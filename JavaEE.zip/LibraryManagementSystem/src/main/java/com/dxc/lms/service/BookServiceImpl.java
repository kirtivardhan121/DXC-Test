package com.dxc.lms.service;

import java.time.LocalDate;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dxc.lms.entity.Book;
import com.dxc.lms.exception.LibraryException;
import com.dxc.lms.repository.BookRepository;

@Service
public class BookServiceImpl implements BookService {

	@Autowired
	private BookRepository bookRepo;

	@Transactional
	@Override
	public Book add(Book book) throws LibraryException {

		if (book != null) {
			if (bookRepo.existsById(book.getBcode())) {
				throw new LibraryException("A Book with bcode " + book.getBcode() + " already exists!!!");
			}
			bookRepo.save(book);
		}
		return book;
	}

	@Transactional
	@Override
	public Book update(Book book) throws LibraryException {

		if (book != null) {
			if (!bookRepo.existsById(book.getBcode())) {
				throw new LibraryException("No such book found!");
			}
			bookRepo.save(book);
		}
		return book;
	}

	@Transactional
	@Override
	public boolean deleteById(int bcode) throws LibraryException {

		boolean deleted = false;

		if (!bookRepo.existsById(bcode)) {
			throw new LibraryException("No such book found to delete!");
		}
		bookRepo.deleteById(bcode);
		return deleted;
	}

	@Transactional
	@Override
	public Book getById(int bcode) throws LibraryException {

		return bookRepo.findById(bcode).orElse(null);
	}

	@Transactional
	@Override
	public List<Book> getAllBooks() throws LibraryException {

		return bookRepo.findAll();
	}

	@Override
	public Book findByBname(String bname) throws LibraryException {

		return bookRepo.findByBname(bname);
	}

	@Override
	public List<Book> findByPackageDate(LocalDate packageDate) throws LibraryException {

		return bookRepo.findAllByPackageDate(packageDate);
	}

	@Override
	public List<Book> findByPriceRange(double lowerBound, double upperBound) throws LibraryException {

		return bookRepo.getAllInPriceRange(lowerBound, upperBound);
	}

}
