package com.dxc.lms.exception;

public class LibraryException extends Exception {

	public LibraryException(String errMsg) {
		super(errMsg);
	}
}
