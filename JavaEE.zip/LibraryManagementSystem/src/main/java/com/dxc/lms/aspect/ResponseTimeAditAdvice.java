package com.dxc.lms.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;

@Component
@Aspect
public class ResponseTimeAditAdvice {

	@Around("execution(org.springframework.web.servlet.ModelAndView com.dxc.lms.controller.*.*(..))")
	public ModelAndView computeResponseTime(ProceedingJoinPoint jp) {
		ModelAndView mv = null;
		Object returnResult = null;
		long startTime = System.currentTimeMillis();
		try {
			returnResult = jp.proceed();
			mv = (ModelAndView) returnResult;
		} catch (ClassCastException exp) {
			mv = new ModelAndView((String) returnResult);
		} catch (Throwable e) {
			e.printStackTrace();
		}
		long endTime = System.currentTimeMillis();
		System.out.println(jp.getSignature().getName() + " ExecutionDuration: " + (endTime - startTime) + "ms");
		return mv;
	}
}
