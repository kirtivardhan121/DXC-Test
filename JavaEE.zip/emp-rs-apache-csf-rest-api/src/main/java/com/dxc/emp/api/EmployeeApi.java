package com.dxc.emp.api;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import com.dxc.emp.model.Employee;

@Path("employees")
public class EmployeeApi {

	private List<Employee> employees;

	public EmployeeApi() {

		employees = new ArrayList<Employee>(Arrays
				.asList(new Employee[] { new Employee(101, "vardhan", 2980.0), new Employee(102, "shashi", 29820.0),
						new Employee(103, "rahul", 23980.0), new Employee(104, "guru", 22980.0) }));

	}

	@GET
	@Produces("application/json")
	public Response getAll() {
		return Response.ok(employees).build();
	}

	@GET
	@Path("{employeeId}")
	@Produces("application/json")
	public Response getById(@PathParam("employeeId") int empId) {
		Employee employee = employees.stream().filter((s) -> s.getEmpId() == empId).findAny().orElse(null);

		Response response = null;

		if (employee == null) {
			response = Response.status(404).build();
		} else {
			response = Response.ok(employee).build();
		}
		return response;
	}

	@POST
	@Produces("application/json")
	@Consumes("application/json")
	public Response createStudent(Employee employee) {

		Response response = null;

		boolean isExisting = employees.stream().anyMatch(s -> s.getEmpId() == employee.getEmpId());

		if (isExisting) {
			response = Response.status(409).build();
		} else {

			employees.add(employee);
			response = Response.ok(employee).build();
		}

		return response;
	}

	@PUT
	@Produces("application/json")
	@Consumes("application/json")
	public Response updateStudent(Employee employee) {

		Response response = null;

		Employee oldEmployee = employees.stream().filter(s -> s.getEmpId() == employee.getEmpId()).findAny()
				.orElse(null);

		if (oldEmployee == null) {
			response = Response.status(400).build();
		} else {
			int index = employees.indexOf(oldEmployee);
			employees.set(index, employee);
			response = Response.ok(employee).build();
		}

		return response;
	}

	@DELETE
	@Path("{employeeId}")
	public Response deleteById(@PathParam("employeeId") int empId) {
		Employee employee = employees.stream().filter((s) -> s.getEmpId() == empId).findAny().orElse(null);

		Response response = null;

		if (employee == null) {
			response = Response.status(404).build();
		} else {
			employees.remove(employee);
			response = Response.ok().build();
		}
		return response;
	}
}
