package com.dxc.sl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWebBootDataRestApiSecurityJwtLibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
