package com.dxc.libraryapi.exception;

public class BookException extends Exception
{
	public BookException(String errMsg)
	{
		super(errMsg);
	}

}