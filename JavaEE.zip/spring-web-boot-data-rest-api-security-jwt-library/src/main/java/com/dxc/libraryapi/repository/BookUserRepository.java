package com.dxc.libraryapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dxc.libraryapi.entity.LibraryUser;

@Repository
public interface BookUserRepository extends JpaRepository<LibraryUser, String> {

}
