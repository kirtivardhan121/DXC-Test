package com.dxc.swd.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.dxc.swd.entity.AppUser;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

	private List<AppUser> appUsers;
		
	
	
	private PasswordEncoder pEnc;
	
	@Autowired
	public UserDetailsServiceImpl(PasswordEncoder pEnc) {
		
		this.pEnc = pEnc;
		
		appUsers = Arrays.asList(new AppUser[] {
			
				new AppUser(101L, "admin", pEnc.encode("admin"), true),
				new AppUser(102L, "test", pEnc.encode("test"), false),
				new AppUser(103L, "vardhan", pEnc.encode("vardhan"), true)
		});
	}
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		UserDetails userDetails;

		/*
		 * if ("admin".equals(username)) { userDetails = (UserDetails) new User("admin",
		 * pEnc.encode("admin") , new ArrayList<>()); } else { throw new
		 * UsernameNotFoundException("No Such User Found!!"); }
		 */

	List<AppUser> foundUsers = appUsers.stream().filter(u -> u.getUserName().equals(username)).collect(Collectors.toList());
	
	if(foundUsers==null || foundUsers.size()==0) {
		throw new UsernameNotFoundException("No Such User Found!!");
	}
	userDetails = (UserDetails) new User(foundUsers.get(0).getUserName(),foundUsers.get(0).getEncryptedPassword(), new ArrayList<>());
	
	if(!foundUsers.get(0).isEnabled()) {
		throw new UsernameNotFoundException("Sorry your Accound is suspended!!");
	}
		
		return userDetails;
	}

}
