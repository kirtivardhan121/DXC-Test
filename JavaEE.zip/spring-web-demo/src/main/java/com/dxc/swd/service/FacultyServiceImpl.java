package com.dxc.swd.service;

import org.springframework.stereotype.Service;

import com.dxc.swd.model.FacultyLeave;

@Service
public class FacultyServiceImpl implements FacultyService {

	@Override
	public FacultyLeave computeFacultyLeave(FacultyLeave faLeave) {
		
		
		return null;
	}

}
