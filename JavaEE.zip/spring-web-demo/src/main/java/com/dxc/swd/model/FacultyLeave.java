package com.dxc.swd.model;

public class FacultyLeave {

	private int id;
	private String firstName;
	private String lastName;
	private LeaveType leaveType;
	
	private int noOfDaysOfLeave;
	
	public FacultyLeave() {
		// left unimplemented
	}

	public FacultyLeave(int id, String firstName, String lastName, LeaveType leaveType, int noOfDaysOfLeave) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.leaveType = leaveType;
		this.noOfDaysOfLeave = noOfDaysOfLeave;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public LeaveType getLeaveType() {
		return leaveType;
	}

	public void setLeaveType(LeaveType leaveType) {
		this.leaveType = leaveType;
	}

	public int getNoOfDaysOfLeave() {
		return noOfDaysOfLeave;
	}

	public void setNoOfDaysOfLeave(int noOfDaysOfLeave) {
		this.noOfDaysOfLeave = noOfDaysOfLeave;
	}
	
	
}
