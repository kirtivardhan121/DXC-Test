package com.dxc.restdemo.api;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import com.dxc.restdemo.model.Student;

@Path("students")
public class StudentApi {

	private List<Student> students;

	public StudentApi() {
		students = new ArrayList<>(Arrays.asList(new Student[] { new Student(101, "vardhan", "MBA"),
				new Student(102, "kirti", "MCA"), new Student(103, "raj", "MBA"), new Student(104, "harsh", "MCA"),
				new Student(105, "yash", "MBA") }));
	}

	@GET
	@Produces("application/json")
	public Response getAll() {
		return Response.ok(students).build();
	}

	@GET
	@Path("{studentId}")
	@Produces("application/json")
	public Response getById(@PathParam("studentId") int admNo) {
		Student student = students.stream().filter((s) -> s.getAdmNo() == admNo).findAny().orElse(null);

		Response response = null;

		if (student == null) {
			response = Response.status(404).build();
		} else {
			response = Response.ok(student).build();
		}
		return response;
	}

	@POST
	@Produces("application/json")
	@Consumes("application/json")
	public Response createStudent(Student student) {

		Response response = null;

		boolean isExisting = students.stream().anyMatch(s -> s.getAdmNo() == student.getAdmNo());

		if (isExisting) {
			response = Response.status(409).build();
		} else {

			students.add(student);
			response = Response.ok(student).build();
		}

		return response;
	}

	@PUT
	@Produces("application/json")
	@Consumes("application/json")
	public Response updateStudent(Student student) {

		Response response = null;

		Student oldStudent = students.stream().filter(((s) -> s.getAdmNo() == student.getAdmNo())).findAny()
				.orElse(null);

		if (oldStudent == null) {
			response = Response.status(400).build();
		} else {
			int index = students.indexOf(oldStudent);
			students.set(index, student);
			response = Response.ok(student).build();
		}

		return response;
	}

	@DELETE
	@Path("{studentId}")
	public Response deleteById(@PathParam("studentId") int admNo) {
		Student student = students.stream().filter((s) -> s.getAdmNo() == admNo).findAny().orElse(null);

		Response response = null;

		if (student == null) {
			response = Response.status(404).build();
		} else {
			students.remove(student);
			response = Response.ok().build();
		}
		return response;
	}
}
