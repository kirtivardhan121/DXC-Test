package com.dxc.restdemo.model;

import java.io.Serializable;

public class Student implements Serializable {

	private int admNo;
	private String name;
	private String course;

	public Student() {
		// unimplemented
	}

	public Student(int admNo, String name, String course) {
		super();
		this.admNo = admNo;
		this.name = name;
		this.course = course;
	}

	public int getAdmNo() {
		return admNo;
	}

	public void setAdmNo(int admNo) {
		this.admNo = admNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

}
