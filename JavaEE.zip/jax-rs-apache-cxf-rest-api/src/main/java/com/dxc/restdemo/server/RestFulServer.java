package com.dxc.restdemo.server;

import org.apache.cxf.endpoint.Server;
import org.apache.cxf.jaxrs.JAXRSServerFactoryBean;
import org.apache.cxf.jaxrs.lifecycle.SingletonResourceProvider;
import org.codehaus.jackson.jaxrs.JacksonJsonProvider;

import com.dxc.restdemo.api.StudentApi;

public class RestFulServer {

	public static void main(String[] args) {

		JAXRSServerFactoryBean serverFactory = new JAXRSServerFactoryBean();

		serverFactory.setResourceClasses(StudentApi.class);

		serverFactory.setResourceProvider(new SingletonResourceProvider(new StudentApi()));

		JacksonJsonProvider jsonProvider = new JacksonJsonProvider();

		serverFactory.setProvider(jsonProvider);

		serverFactory.setAddress("http://localhost:8765");

		Server server = serverFactory.create();
	}
}
