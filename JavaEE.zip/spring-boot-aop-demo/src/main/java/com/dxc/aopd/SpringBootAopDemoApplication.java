package com.dxc.aopd;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import com.dxc.aopd.service.CalcService;
import com.dxc.aopd.service.GreetService;

@SpringBootApplication
@EnableAspectJAutoProxy
public class SpringBootAopDemoApplication implements CommandLineRunner{

	@Autowired
	private GreetService gs;
	
	@Autowired
	private CalcService cs;
	
	public static void main(String[] args) {
		SpringApplication.run(SpringBootAopDemoApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("This is my first Console based Application on Spring boot");
		
		
		System.out.println(gs.greet());
		System.out.println(cs.sum(3, 4));
		System.out.println(cs.dif(10, 5));
		System.out.println(cs.prd(2, 3));
		System.out.println(cs.qut(10, 5));
		//System.out.println(cs.qut(10, 0));
	}

}
