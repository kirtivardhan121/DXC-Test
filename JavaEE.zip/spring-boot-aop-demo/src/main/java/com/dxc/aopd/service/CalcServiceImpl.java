package com.dxc.aopd.service;

import org.springframework.stereotype.Service;

@Service
public class CalcServiceImpl implements CalcService {

	@Override
	public Integer sum(int a, int b) {
		System.out.println("Sum is being Executed");
		return a+b;
	}

	@Override
	public Integer dif(int a, int b) {
		System.out.println("Difference is being Executed");
		return a-b;
	}

	@Override
	public Integer prd(int a, int b) {
		System.out.println("Product is being Executed");
		return a*b;
	}

	@Override
	public Integer qut(int a, int b) {
		
		return a%b;
	}

}
