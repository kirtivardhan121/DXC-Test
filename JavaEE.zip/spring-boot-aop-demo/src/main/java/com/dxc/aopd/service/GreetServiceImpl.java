package com.dxc.aopd.service;

import org.springframework.stereotype.Service;

@Service
public class GreetServiceImpl implements GreetService {

	@Override
	public String greet() {
		System.out.println("Greet is being Executed");
		return "Hello!";
	}

}
