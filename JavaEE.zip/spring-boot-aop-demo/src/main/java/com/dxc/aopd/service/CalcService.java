package com.dxc.aopd.service;

public interface CalcService {

	Integer sum(int a, int b);
	Integer dif(int a, int b);
	Integer prd(int a, int b);
	Integer qut(int a, int b);
}
