package com.dxc.aopd.service;

public interface GreetService {

	public String greet();
}
