package com.dxc.aopd.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class MyAdvice1 {

	@Before("execution(* com.dxc.aopd.service.*.*(..))")
	public void crossCutFunction1(JoinPoint jp) {
		System.out.println("I am Being called before executing: " + jp.getSignature().getName());
	}

	@AfterReturning("execution(* com.dxc.aopd.service.*.*(..))")
	public void crossCutFunction2(JoinPoint jp) {
		System.out.println("I am Being called after executing: " + jp.getSignature().getName());
	}

	 @AfterThrowing("execution(* com.dxc.aopd.service.*.*(..))") public void
	 crossCutFunction3(JoinPoint jp) {
	 System.out.println("I am Being called after throwing exception from: "+jp.
	 getSignature().getName()); }
	 
	 @Around("execution(* com.dxc.aopd.service.*.*(..))") public void
	 crossCutFunction4(JoinPoint jp) {
	 System.out.println("I am Being called around-before: "+jp.getSignature().
	 getName()); jp.getTarget();
	 System.out.println("I am Being called around-after: "+jp.getSignature().
	 getName()); }
	 
}
