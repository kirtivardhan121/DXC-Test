package com.dxc.swd.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ArithmeticController {

	@RequestMapping("/arithmetic")
	public ModelAndView arithmeticCalci(
			@RequestParam(name = "op1", required = false) Integer operand1,
			@RequestParam(name = "op2", required = false) Integer operand2, 
			@RequestParam(name = "operation", required = false) String operation) {
		
		ModelAndView mv = new ModelAndView();
		
		mv.setViewName("arithmeticPage");
		
		String result = null;
		
		if(operation != null) {
			
			switch(operation) {
			case "sum": result = "sum is " +(operand1 + operand2);
				break;
			case "dif": result = "dif is " +(operand1 - operand2);
				break;
			case "prd": result = "prd is " +(operand1 * operand2);
				break;
			case "qut": result = "qut is " +(operand1 / operand2);
				break;
			case "rem": result = "rem is " +(operand1 % operand2);
				break;
			default:
				break;
			}
		}
		
		mv.addObject("result", result);
		return mv;
	}
	
}
