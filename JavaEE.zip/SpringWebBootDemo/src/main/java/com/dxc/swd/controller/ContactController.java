package com.dxc.swd.controller;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dxc.swd.model.Address;
import com.dxc.swd.model.Contact;

@Controller
@Scope("session")
public class ContactController {

	private Contact contact;
	
	@GetMapping("/contact")
	public ModelAndView showContactForm() {
		return new ModelAndView("contactInfoPage","contact",new Contact());
	}
	
	@PostMapping("/contact")
	public ModelAndView acceptContactForm(@ModelAttribute Contact contact) {
		this.contact = contact;
		return new ModelAndView("addressInfoPage", "address", new Address());
	}
	
	@PostMapping("/address")
	public ModelAndView acceptAddressForm(@ModelAttribute Address address) {
		this.contact.setAddress(address);
		return new ModelAndView("contactOutputPage","contact",this.contact);
	}
}
