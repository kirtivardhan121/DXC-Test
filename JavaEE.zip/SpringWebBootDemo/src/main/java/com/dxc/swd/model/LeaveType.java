package com.dxc.swd.model;

public enum LeaveType {

	CASUAL,SICK,EARNED;
}
