package com.dxc.swd.service;

import org.springframework.stereotype.Service;

import com.dxc.swd.model.FacultyLeave;

@Service
public class FacultyServiceImpl implements FacultyService {

	@Override
	public FacultyLeave computeFacultyLeave(FacultyLeave faLeave) {

		int leave = 0;

		switch (faLeave.getLeaveType()) {
		case CASUAL:
			if (faLeave.getNoOfDaysOfLeave() >= 1 && faLeave.getNoOfDaysOfLeave() <= 5) {

				leave = faLeave.getNoOfDaysOfLeave();
				faLeave.setValidLeave(String.valueOf(leave));
			} else {
				faLeave.setValidLeave("Casual leave can not be granted");

			}
			break;

		case SICK:
			if (faLeave.getNoOfDaysOfLeave() >= 7 && faLeave.getNoOfDaysOfLeave() <= 30) {

				leave = faLeave.getNoOfDaysOfLeave();
				faLeave.setValidLeave(String.valueOf(leave));
			} else {
				faLeave.setValidLeave("Sick leave not be granted");
			}
			break;

		case EARNED:
			if (faLeave.getNoOfDaysOfLeave() >= 2 && faLeave.getNoOfDaysOfLeave() <= 10) {

				leave = faLeave.getNoOfDaysOfLeave();
				faLeave.setValidLeave(String.valueOf(leave));
			} else {
				faLeave.setValidLeave("Earned leave not be granted");
			}
			break;

		}

		return faLeave;
	}

}
