package com.dxc.swd.service;

import org.springframework.stereotype.Service;

import com.dxc.swd.model.Farmer;

@Service
public class FarmerServiceImpl implements FarmerService {

	@Override
	public void computeLoan(Farmer farmer) {
		

		double maxLoan = 0;
		
		switch(farmer.getCropType()) {
		case "CERALS":
			maxLoan = 100000;
			break;
		case "PULSES":
			maxLoan = 200000;
			break;
		case "COMERCIALS":
			maxLoan = 500000;
			break;
		case "FISH":
			maxLoan = 400000;
			break;
			
		default:
			System.out.println("Invalid Choice");
			break;
		}
		
		double Amount = maxLoan * farmer.getFieldArea() - farmer.getOldLoan();
		farmer.setAmount(Amount);
	}

}
