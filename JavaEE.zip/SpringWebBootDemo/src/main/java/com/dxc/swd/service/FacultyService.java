package com.dxc.swd.service;

import com.dxc.swd.model.FacultyLeave;

public interface FacultyService {

	FacultyLeave computeFacultyLeave(FacultyLeave faLeave);
}
