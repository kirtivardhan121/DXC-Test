package com.dxc.swd.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class DefaultController {

	/*
	 * assuming 9090 is the port
	 * 
	 * http://localhost:9090/SpringWebDemo 
	 * http://localhost:9090/SpringWebDemo/
	 * http://localhost:9090/SpringWebDemo/home
	 */

	@RequestMapping({ "", "/", "/home" })
	public String showHomePage() {
		return "home";
	}
	
	@RequestMapping("/contact")
	public ModelAndView showContactUsPages() {
		
		ModelAndView mv = new ModelAndView();
		
		mv.setViewName("contactPage");
		mv.addObject("emailId", "webAdmin@dxc.com");
		mv.addObject("Mobiles", new String[] {"9876564567","876798765"});
		
		return mv;
	}
	
	@RequestMapping("/nav")
	public String getNav() {
		return "navPage";
	}
}
