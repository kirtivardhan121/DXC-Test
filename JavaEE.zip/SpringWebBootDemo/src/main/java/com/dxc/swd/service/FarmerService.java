package com.dxc.swd.service;

import com.dxc.swd.model.Farmer;

public interface FarmerService {

	public void computeLoan(Farmer farmer);
}
