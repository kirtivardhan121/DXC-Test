package com.dxc.swd.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.dxc.swd.model.Farmer;
import com.dxc.swd.service.FarmerService;

@Controller
public class FarmerController {

	@Autowired
	private FarmerService farmerService;
	
	@RequestMapping(value = "/farmer", method = RequestMethod.GET)
	public String showFarmerPage() {
		return "farmerInputPage";
	}
	
	
	@RequestMapping(value = "/farmer", method = RequestMethod.POST)
	public ModelAndView acceptFarmer(@ModelAttribute Farmer farmer) {
		
		farmerService.computeLoan(farmer);
		
		return new ModelAndView("farmerOutputPage", "farmer", farmer);
	}
}
