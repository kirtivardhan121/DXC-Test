package com.dxc.swd.service;

import com.dxc.swd.model.Employee;

public interface EmployeeService {

	public void computeAllowence(Employee emp);
}
