package com.dxc.swd.model;

public class Farmer {

	private double fieldArea;
	private String cropType;
	private double oldLoan;
	private double amount;
	
	public Farmer() {
		// left unimplemented
	}

	public Farmer(double fieldArea, String cropType, double oldLoan, double amount) {
		super();
		this.fieldArea = fieldArea;
		this.cropType = cropType;
		this.oldLoan = oldLoan;
		this.amount = amount;
	}

	public double getFieldArea() {
		return fieldArea;
	}

	public void setFieldArea(double fieldArea) {
		this.fieldArea = fieldArea;
	}

	public String getCropType() {
		return cropType;
	}

	public void setCropType(String cropType) {
		this.cropType = cropType;
	}

	public double getOldLoan() {
		return oldLoan;
	}

	public void setOldLoan(double oldLoan) {
		this.oldLoan = oldLoan;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	
}
