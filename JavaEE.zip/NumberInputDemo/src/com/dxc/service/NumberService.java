package com.dxc.service;

public class NumberService {

	public double power(double n1, double n2) {
		return Math.pow(n1, n2);
	}
}
