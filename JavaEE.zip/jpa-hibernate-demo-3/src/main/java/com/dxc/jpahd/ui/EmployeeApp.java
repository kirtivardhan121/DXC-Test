package com.dxc.jpahd.ui;

import java.time.LocalDate;
import java.util.TreeSet;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.dxc.jpahd.entity.Address;
import com.dxc.jpahd.entity.BankAccount;
import com.dxc.jpahd.entity.Department;
import com.dxc.jpahd.entity.Employee;

public class EmployeeApp {

	public static void main(String[] args) {
		
		
		Department d1 = new Department(null, "Accounts");
		Department d2 = new Department(null, "Sales");
		
		d1.setEmployees(new TreeSet<Employee>());
		d1.getEmployees().add(new Employee(105L, "Arjun", "kbc", 25000.0, LocalDate.now(), new Address("108", "BTM", "Bangalore"), new BankAccount(1098769L, "BTM", "HDFC"),d1));
		d1.getEmployees().add(new Employee(106L, "kush", "kbc", 25000.0, LocalDate.now(), new Address("109", "BTM", "Bangalore"), new BankAccount(1098778L, "BTM", "HDFC"),d1));
		
		for(Employee e:d1.getEmployees()) {
			e.getSalAccount().setAccountHolder(e);;
		}
		
		d2.setEmployees(new TreeSet<Employee>());
		d2.getEmployees().add(new Employee(107L, "luv", "kbc", 25000.0, LocalDate.now(), new Address("110", "BTM", "Bangalore"), new BankAccount(1098762L, "BTM", "HDFC"),d2));
		d2.getEmployees().add(new Employee(108L, "laxman", "kbc", 25000.0, LocalDate.now(), new Address("111", "BTM", "Bangalore"), new BankAccount(1008764L, "BTM", "HDFC"),d2));
		
		for(Employee e:d2.getEmployees()) {
			e.getSalAccount().setAccountHolder(e);;
		}
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("mysqlPU");
		EntityManager em = emf.createEntityManager();
		
		EntityTransaction txn = em.getTransaction();
		
		txn.begin();
		
		em.persist(d1);
		em.persist(d2);
		txn.commit();
		
		System.out.println("Data saved!!!");
		
		em.close();
	}
}
