package com.dxc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class DefaultController {

	/*
	 * assuming 9090 is the port
	 * 
	 * http://localhost:9090/SpringWebDemo 
	 * http://localhost:9090/SpringWebDemo/
	 * http://localhost:9090/SpringWebDemo/home
	 */

	@RequestMapping({ "", "/", "/home" })
	public String showHomePage() {
		return "home";
	}
}
