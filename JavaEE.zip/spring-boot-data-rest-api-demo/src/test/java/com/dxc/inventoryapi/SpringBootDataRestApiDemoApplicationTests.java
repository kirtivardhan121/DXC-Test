package com.dxc.inventoryapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDataRestApiDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
