package com.dxc.inventoryapi.exception;

public class ItemException extends Exception{

	public ItemException(String errMsg) {
		super(errMsg);
	}
}
