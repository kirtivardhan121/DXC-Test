package com.dxc.swd.exception;

public class ItemException extends Exception{

	public ItemException(String errMsg) {
		super(errMsg);
	}
}
