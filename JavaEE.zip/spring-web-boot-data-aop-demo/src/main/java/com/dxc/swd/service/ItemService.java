package com.dxc.swd.service;

import java.time.LocalDate;
import java.util.List;

import com.dxc.swd.entity.Item;
import com.dxc.swd.exception.ItemException;

public interface ItemService {

	Item add(Item item) throws ItemException;
	Item update(Item item) throws ItemException;
	boolean deleteById(int icode) throws ItemException;
	Item getById(int icode) throws ItemException;
	List<Item> getAllItems() throws ItemException;

	Item findByIname(String iname);
	List<Item> findByPackageDate(LocalDate packageDate);
	List<Item> findByPriceRange(double lowerBound, double upperBound);
}
