package com.dxc.swd.controller;

import java.time.LocalDate;
import java.util.Collections;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.dxc.swd.entity.Item;
import com.dxc.swd.exception.ItemException;
import com.dxc.swd.service.ItemService;

@Controller
public class ItemController {

	@Autowired
	private ItemService itemService;

	@GetMapping({ "", "/", "/home" })
	public ModelAndView itemList() throws ItemException {

		return new ModelAndView("itemListPage", "items", itemService.getAllItems());
	}

	@GetMapping("/newItem")
	public ModelAndView newItem() {

		return new ModelAndView("itemFormPage", "item", new Item());
	}

	@PostMapping("/newItem")
	public ModelAndView doNewItem(@Valid @ModelAttribute("item") Item item, BindingResult result) throws ItemException {
		ModelAndView mv;

		if (result.hasErrors()) {
			mv = new ModelAndView("itemFormPage", "item", item);
		} else {
			itemService.add(item);
			mv = new ModelAndView("redirect:/home");
		}

		return mv;
	}

	@GetMapping("/deleteItem")
	public ModelAndView deleteItem(@RequestParam(name = "icode") int icode) throws ItemException {
		return new ModelAndView("deletePage", "item", itemService.getById(icode));
	}

	@PostMapping("/deleteItem")
	public String confirmDelete(@RequestParam(name = "icode") int icode,
			@RequestParam(name = "confirm") boolean confirm) throws ItemException {

		if (confirm) {
			itemService.deleteById(icode);
		}
		return "redirect:/home";
	}
	
	@GetMapping("/editItem")
	public ModelAndView editItem(@RequestParam(name = "icode") int icode) throws ItemException {
		return new ModelAndView("itemFormPage", "item", itemService.getById(icode));
	}
	
	@PostMapping("/editItem")
	public ModelAndView doUpdateItem(@Valid @ModelAttribute("item") Item item, BindingResult result) throws ItemException {
		ModelAndView mv;

		if (result.hasErrors()) {
			mv = new ModelAndView("itemFormPage", "item", item);
		} else {
			itemService.update(item);
			mv = new ModelAndView("redirect:/home");
		}

		return mv;
	}
	
	@GetMapping("/findByIname")
	public ModelAndView itemByTitle(@RequestParam("iname") String iname) throws ItemException {

		return new ModelAndView("itemListPage", "items", Collections.singletonList(itemService.findByIname(iname)));
	}
	
	@GetMapping("/findByPackageDate")
	public ModelAndView itemByPDate(@DateTimeFormat(iso = ISO.DATE) @RequestParam("packageDate") LocalDate packageDate) throws ItemException {

		return new ModelAndView("itemListPage", "items", itemService.findByPackageDate(packageDate));
	}
	
	@GetMapping("/findByPriceRange")
	public ModelAndView itemByPrice(@RequestParam("lb") double lowerBound, @RequestParam("ub") double upperBound) throws ItemException {

		 return new ModelAndView("itemListPage", "items",itemService.findByPriceRange(lowerBound, upperBound));
    
	}
}
