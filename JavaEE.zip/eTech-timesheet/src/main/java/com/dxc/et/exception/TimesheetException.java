package com.dxc.et.exception;

public class TimesheetException extends Exception {

	public TimesheetException(String errMsg) {
		super(errMsg);
	}
}//end of TimesheetException
