package com.dxc.et.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dxc.et.entity.Client;
import com.dxc.et.exception.TimesheetException;
import com.dxc.et.repository.TimsheetRepository;

@Service
public class TimeSheetServiceImpl implements TimesheetService {

	String shortfall = "";

	@Autowired
	private TimsheetRepository timesheetRepo;

	/*
	 * add() method will check if the Employee code is already exist or not, if not
	 * exist it'll add data otherwise it'll throw TimesheetException
	 */
	@Transactional
	@Override
	public Client add(Client client) throws TimesheetException {
		if (client != null) {
			if (timesheetRepo.existsById(client.getEmpCode())) {
				throw new TimesheetException("An Employee With empcode " + client.getEmpCode() + " already exist!!");
			}
			client.setShortfall(shortfall);
			timesheetRepo.save(client);
		}
		return client;
	}

	/*
	 * getAllClients() method will check if the Employee data is already exist or
	 * not, if not exist it'll print no data available or else it'll print data
	 * present in table
	 */

	@Transactional
	@Override
	public List<Client> getAllClients() throws TimesheetException {
		return timesheetRepo.findAll();
	}

	/*
	 * getById() method will check if the Employee code is exist or not, if not
	 * exist it'll throw TimesheetException otherwise it'll print data available for
	 * particular employee code
	 */
	@Transactional
	@Override
	public Client getById(int empCode) throws TimesheetException {

		return timesheetRepo.findById(empCode).orElse(null);
	}

	/*
	 * totalHours() method will check if the shortfall is equal to or greater than
	 * 45, then it'll add short-fall as Yes otherwise it'll add No in database
	 * 
	 */
	@Override
	public void totalHours(Client client) throws TimesheetException {
		int hours = client.getMonHours() + client.getTueHours() + client.getWedHours() + client.getThuHours()
				+ client.getFriHours() + client.getSatHours() + client.getSunHours();
		if (hours >= 45) {
			shortfall = "Y";
		} else {
			shortfall = "N";
		}
	}

}// end of TimeSheetServiceImpl
