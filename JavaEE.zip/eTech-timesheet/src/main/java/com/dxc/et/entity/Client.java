package com.dxc.et.entity;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.FutureOrPresent;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

@Entity
@Table(name = "timesheet")
public class Client implements Serializable {

	@Id
	@Column(name = "employee_code")
	@NotNull(message = "employee code can not be blank")
	@Min(value = 6, message = "can not be lessthan 6 digits")
	private Integer empCode;

	@Column(name = "entry_date", nullable = false)
	@FutureOrPresent(message = "entry date can not be past date")
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate entryDate;

	@Column(name = "mon_hrs", nullable = false)
	@NotNull(message = "Can not be blank")
	@Min(value = 0, message = "must be equal or greater than 0")
	@Max(value = 24, message = "must be equal or less than 24")
	private Integer monHours;

	@Column(name = "mon_activity", nullable = false)
	@NotNull(message = "Activity can not be blank")
	private Activity monActivity;

	@Column(name = "tue_hrs", nullable = false)
	@NotNull(message = "Can not be blank")
	@Min(value = 0, message = "must be equal or greater than 0")
	@Max(value = 24, message = "must be equal or less than 24")
	private Integer tueHours;

	@Column(name = "tue_activity", nullable = false)
	@NotNull(message = "Activity can not be blank")
	private Activity tueActivity;

	@Column(name = "wed_hrs", nullable = false)
	@NotNull(message = "Can not be blank")
	@Min(value = 0, message = "must be equal or greater than 0")
	@Max(value = 24, message = "must be equal or less than 24")
	private Integer wedHours;

	@Column(name = "wed_activity", nullable = false)
	@NotNull(message = "Activity can not be blank")
	private Activity wedActivity;

	@Column(name = "thu_hrs", nullable = false)
	@NotNull(message = "Can not be blank")
	@Min(value = 0, message = "must be equal or greater than 0")
	@Max(value = 24, message = "must be equal or less than 24")
	private Integer thuHours;

	@Column(name = "thu_activity", nullable = false)
	@NotNull(message = "Activity can not be blank")
	private Activity thuActivity;

	@Column(name = "fri_hrs", nullable = false)
	@NotNull(message = "Can not be blank")
	@Min(value = 0, message = "must be equal or greater than 0")
	@Max(value = 24, message = "must be equal or less than 24")
	private Integer friHours;

	@Column(name = "fri_activity", nullable = false)
	@NotNull(message = "Activity can not be blank")
	private Activity friActivity;

	@Column(name = "sat_hrs", nullable = false)
	@NotNull(message = "Can not be blank")
	@Min(value = 0, message = "must be equal or greater than 0")
	@Max(value = 24, message = "must be less than 24")
	private Integer satHours;

	@Column(name = "sat_activity", nullable = false)
	@NotNull(message = "Activity can not be blank")
	private Activity satActivity;

	@Column(name = "sun_hrs", nullable = false)
	@NotNull(message = "Can not be blank")
	@Min(value = 0, message = "must be equal or greater than 0")
	@Max(value = 24, message = "must be equal or less than 24")
	private Integer sunHours;

	@Column(name = "sun_activity", nullable = false)
	@NotNull(message = "Activity can not be blank")
	private Activity sunActivity;

	@Column(name = "short_fall", nullable = true)
	private String shortfall;

	public Client() {
		// left unimplemented
	}

	public Client(@NotNull(message = "employee code can not be blank") Integer empCode,
			@FutureOrPresent(message = "entry date can not be past date") LocalDate entryDate,
			@NotNull(message = "Can not be blank") @Min(value = 0, message = "must be equal or greater than 0") @Max(value = 24, message = "must be equal or less than 24") Integer monHours,
			@NotNull(message = "Activity can not be blank") Activity monActivity,
			@NotNull(message = "Can not be blank") @Min(value = 0, message = "must be equal or greater than 0") @Max(value = 24, message = "must be equal or less than 24") Integer tueHours,
			@NotNull(message = "Activity can not be blank") Activity tueActivity,
			@NotNull(message = "Can not be blank") @Min(value = 0, message = "must be equal or greater than 0") @Max(value = 24, message = "must be equal or less than 24") Integer wedHours,
			@NotNull(message = "Activity can not be blank") Activity wedActivity,
			@NotNull(message = "Can not be blank") @Min(value = 0, message = "must be equal or greater than 0") @Max(value = 24, message = "must be equal or less than 24") Integer thuHours,
			@NotNull(message = "Activity can not be blank") Activity thuActivity,
			@NotNull(message = "Can not be blank") @Min(value = 0, message = "must be equal or greater than 0") @Max(value = 24, message = "must be equal or less than 24") Integer friHours,
			@NotNull(message = "Activity can not be blank") Activity friActivity,
			@NotNull(message = "Can not be blank") @Min(value = 0, message = "must be equal or greater than 0") @Max(value = 24, message = "must be less than 24") Integer satHours,
			@NotNull(message = "Activity can not be blank") Activity satActivity,
			@NotNull(message = "Can not be blank") @Min(value = 0, message = "must be equal or greater than 0") @Max(value = 24, message = "must be equal or less than 24") Integer sunHours,
			@NotNull(message = "Activity can not be blank") Activity sunActivity, String shortfall) {
		super();
		this.empCode = empCode;
		this.entryDate = entryDate;
		this.monHours = monHours;
		this.monActivity = monActivity;
		this.tueHours = tueHours;
		this.tueActivity = tueActivity;
		this.wedHours = wedHours;
		this.wedActivity = wedActivity;
		this.thuHours = thuHours;
		this.thuActivity = thuActivity;
		this.friHours = friHours;
		this.friActivity = friActivity;
		this.satHours = satHours;
		this.satActivity = satActivity;
		this.sunHours = sunHours;
		this.sunActivity = sunActivity;
		this.shortfall = shortfall;
	}

	public Integer getEmpCode() {
		return empCode;
	}

	public void setEmpCode(Integer empCode) {
		this.empCode = empCode;
	}

	public LocalDate getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(LocalDate entryDate) {
		this.entryDate = entryDate;
	}

	public Integer getMonHours() {
		return monHours;
	}

	public void setMonHours(Integer monHours) {
		this.monHours = monHours;
	}

	public Activity getMonActivity() {
		return monActivity;
	}

	public void setMonActivity(Activity monActivity) {
		this.monActivity = monActivity;
	}

	public Integer getTueHours() {
		return tueHours;
	}

	public void setTueHours(Integer tueHours) {
		this.tueHours = tueHours;
	}

	public Activity getTueActivity() {
		return tueActivity;
	}

	public void setTueActivity(Activity tueActivity) {
		this.tueActivity = tueActivity;
	}

	public Integer getWedHours() {
		return wedHours;
	}

	public void setWedHours(Integer wedHours) {
		this.wedHours = wedHours;
	}

	public Activity getWedActivity() {
		return wedActivity;
	}

	public void setWedActivity(Activity wedActivity) {
		this.wedActivity = wedActivity;
	}

	public Integer getThuHours() {
		return thuHours;
	}

	public void setThuHours(Integer thuHours) {
		this.thuHours = thuHours;
	}

	public Activity getThuActivity() {
		return thuActivity;
	}

	public void setThuActivity(Activity thuActivity) {
		this.thuActivity = thuActivity;
	}

	public Integer getFriHours() {
		return friHours;
	}

	public void setFriHours(Integer friHours) {
		this.friHours = friHours;
	}

	public Activity getFriActivity() {
		return friActivity;
	}

	public void setFriActivity(Activity friActivity) {
		this.friActivity = friActivity;
	}

	public Integer getSatHours() {
		return satHours;
	}

	public void setSatHours(Integer satHours) {
		this.satHours = satHours;
	}

	public Activity getSatActivity() {
		return satActivity;
	}

	public void setSatActivity(Activity satActivity) {
		this.satActivity = satActivity;
	}

	public Integer getSunHours() {
		return sunHours;
	}

	public void setSunHours(Integer sunHours) {
		this.sunHours = sunHours;
	}

	public Activity getSunActivity() {
		return sunActivity;
	}

	public void setSunActivity(Activity sunActivity) {
		this.sunActivity = sunActivity;
	}

	public String getShortfall() {
		return shortfall;
	}

	public void setShortfall(String shortfall) {
		this.shortfall = shortfall;
	}

}// end of Client
