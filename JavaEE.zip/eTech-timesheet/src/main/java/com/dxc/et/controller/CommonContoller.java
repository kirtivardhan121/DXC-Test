package com.dxc.et.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CommonContoller {

	/*
	 * It is a common controller for all the existing pages
	 */

	@RequestMapping("/header")
	public String header() {

		return "header";
	}

	@RequestMapping("/footer")
	public String footer() {

		return "footer";
	}
}// end of CommonContoller
