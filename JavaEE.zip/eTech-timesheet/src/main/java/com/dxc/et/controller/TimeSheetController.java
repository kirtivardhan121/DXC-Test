package com.dxc.et.controller;

import java.util.Collections;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.dxc.et.entity.Client;
import com.dxc.et.exception.TimesheetException;
import com.dxc.et.service.TimesheetService;

@Controller
public class TimeSheetController {

	@Autowired
	private TimesheetService timesheetService;

	@GetMapping({ "", "/", "/home" })
	public ModelAndView clientHome() {
		return new ModelAndView("HomePage");
	}

	@PostMapping("/findById")
	public ModelAndView clientByEmpNo(@RequestParam("empCode") int empCode) throws TimesheetException {
		return new ModelAndView("clientsListPage", "clients",
				Collections.singletonList(timesheetService.getById(empCode)));
	}

	@GetMapping("/newClient")
	public ModelAndView newClient() {
		return new ModelAndView("clientFormPage", "client", new Client());
	}

	@PostMapping("/newClient")
	public ModelAndView doAddNewClient(@Valid @ModelAttribute("client") Client client, BindingResult result)
			throws TimesheetException {
		ModelAndView mv;

		if (result.hasErrors()) {
			mv = new ModelAndView("clientFormPage", "client", client);
		} else {
			timesheetService.totalHours(client);
			timesheetService.add(client);
			mv = new ModelAndView("redirect:/home");
		}

		return mv;
	}

	@GetMapping("/clientList")
	public ModelAndView clientList() throws TimesheetException {
		return new ModelAndView("clientsListPage", "clients", timesheetService.getAllClients());
	}
}
