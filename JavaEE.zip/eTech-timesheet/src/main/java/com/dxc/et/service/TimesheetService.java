package com.dxc.et.service;

import java.util.List;

import com.dxc.et.entity.Client;
import com.dxc.et.exception.TimesheetException;

public interface TimesheetService {

	Client add(Client client) throws TimesheetException;

	List<Client> getAllClients() throws TimesheetException;

	Client getById(int empCode) throws TimesheetException;

	void totalHours(Client client) throws TimesheetException;

}// end of TimesheetService
