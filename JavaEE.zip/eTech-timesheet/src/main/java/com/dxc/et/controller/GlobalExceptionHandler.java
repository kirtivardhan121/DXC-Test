package com.dxc.et.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.dxc.et.exception.TimesheetException;

@ControllerAdvice
public class GlobalExceptionHandler {

	/*
	 * GlobalExceptionHandler is common exception handler for all the exception
	 * which can occur
	 */
	Logger logger = LoggerFactory.getLogger("ets");

	@ExceptionHandler(TimesheetException.class)
	public ModelAndView handleException(TimesheetException exp) {
		logger.error(exp.getMessage(), exp);
		return new ModelAndView("errorPage", "exception", exp);
	}
}
