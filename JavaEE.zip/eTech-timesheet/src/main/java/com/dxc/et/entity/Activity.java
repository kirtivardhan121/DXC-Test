package com.dxc.et.entity;

public enum Activity {

	REQUIREMENTANALYSIS, CODING, REVIEW, TESTING, OTHERS;

}
