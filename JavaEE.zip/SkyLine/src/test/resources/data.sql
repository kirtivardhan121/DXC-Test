create table Channels( 
channel_id integer primary key, 
name varchar(20) not null, 
language varchar(20) not null, 
category varchar(20) not null, 
subscription_fee double not null
);