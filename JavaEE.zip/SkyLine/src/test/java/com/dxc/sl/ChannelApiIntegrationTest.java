package com.dxc.sl;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;
import org.springframework.test.web.servlet.MockMvc;

import com.dxc.sl.entity.Channels;
import com.dxc.sl.repository.ChannelRepository;

@SpringJUnitConfig
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK, classes = SkyLineApplication.class)
@AutoConfigureMockMvc
@TestPropertySource(locations = "classpath:application-test.properties")

public class ChannelApiIntegrationTest {
	@Autowired
	private MockMvc mvcClient;

	@Autowired
	private ChannelRepository repository;

	private List<Channels> testData;

	private static final String API_URL = "/channels";

	/*
	 * fillTestData() Add data into H2 database(virtual database for whitebox
	 * testing)
	 */

	@BeforeEach
	public void fillTestData() {
		testData = new ArrayList<>();
		testData.add(new Channels(101, "AajTak", "Hindi", "News", 330.0));
		testData.add(new Channels(102, "Colors", "Hindi", "Movies", 230.0));
		testData.add(new Channels(103, "SetMax", "Kannada", "Movies", 130.0));
		testData.add(new Channels(104, "MajhaMaharashtra", "Marathi", "Serials", 100.0));

		for (Channels channel : testData) {
			repository.saveAndFlush(channel);
		}
	}

	/*
	 * clearDatabase() clear all data from H2 database after testing is done
	 */

	@AfterEach
	public void clearDatabase() {
		repository.deleteAll();
		testData = null;
	}

	/*
	 * getAllChannelsTest() tests get all operation with existing data
	 */
	@Test
	public void getAllChannelsTest() {
		try {
			mvcClient.perform(get(API_URL)).andExpect(status().isOk()).andExpect(jsonPath("$", hasSize(4)))
					.andDo(print());
		} catch (Exception e) {
			Assertions.fail(e.getMessage());
		}
	}

	/*
	 * getChannelByIdTest() tests getById operation with existing Id
	 */

	@Test
	public void getChannelsByIdTest() {
		Channels testRec = testData.get(0);

		try {
			mvcClient.perform(get(API_URL + "/" + testRec.getChannel_id())).andExpect(status().isOk())
					.andExpect(jsonPath("$.name", is(testRec.getName())))
					.andExpect(jsonPath("$.language", is(testRec.getLanguage())))
					.andExpect(jsonPath("$.category", is(testRec.getCategory())))
					.andExpect(jsonPath("$.subscription_fee", is(testRec.getSubscription_fee()))).andDo(print());
		} catch (Exception e) {
			Assertions.fail(e.getMessage());
		}
	}

	/*
	 * getChannelByIdTestNonExisting() tests getById operation with non existing Id
	 */

	@Test
	public void getChannelsByIdTestNonExsiting() {

		try {
			mvcClient.perform(get(API_URL + "/9999")).andExpect(status().isNotFound()).andDo(print());
		} catch (Exception e) {
			Assertions.fail(e.getMessage());
		}
	}

	/*
	 * getChannelByNameTest() tests get operation with existing Name
	 */
	@Test
	public void getChannelByNameTest() {
		Channels testRec = testData.get(0);

		try {
			mvcClient.perform(get(API_URL + "/name" + "/" + testRec.getName())).andExpect(status().isOk())
					.andExpect(jsonPath("$.channel_id", is(testRec.getChannel_id())))
					.andExpect(jsonPath("$.language", is(testRec.getLanguage())))
					.andExpect(jsonPath("$.category", is(testRec.getCategory())))
					.andExpect(jsonPath("$.subscription_fee", is(testRec.getSubscription_fee()))).andDo(print());
		} catch (Exception e) {
			Assertions.fail(e.getMessage());
		}
	}

	/*
	 * getChannelBylanguageTest() tests get operation with existing laguage
	 */

	@Test
	public void getChannelByLanguageTest() {
		Channels testRec = testData.get(0);
		try {
			mvcClient.perform(get(API_URL + "/language" + "/" + testRec.getLanguage())).andExpect(status().isOk())
					.andExpect(jsonPath("$", hasSize(2))).andDo(print());
		} catch (Exception e) {
			Assertions.fail(e.getMessage());
		}

	}

	/*
	 * getChannelByCategoryTest() tests get operation with existing category
	 */

	@Test
	public void getChannelByCategoryTest() {
		Channels testRec = testData.get(0);

		try {
			mvcClient.perform(get(API_URL + "/category" + "/" + testRec.getCategory())).andExpect(status().isOk())
					.andExpect(jsonPath("$", hasSize(1))).andDo(print());
		} catch (Exception e) {
			Assertions.fail(e.getMessage());
		}
	}

	/*
	 * deleteChannelByIdTest() tests delete operation with existing id
	 */

	@Test
	public void deleteChannelsByIdTest() {

		try {
			mvcClient.perform(delete(API_URL + "/" + testData.get(0).getChannel_id())).andExpect(status().isOk())
					.andDo(print());
		} catch (Exception e) {
			Assertions.fail(e.getMessage());
		}
	}
}
