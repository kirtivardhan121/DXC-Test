package com.dxc.sl;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import com.dxc.sl.entity.Channels;
import com.dxc.sl.repository.ChannelRepository;

@DataJpaTest
public class ChannelRepositoryTest {

	@Autowired
	private TestEntityManager entityManager;

	@Autowired
	private ChannelRepository channelRepository;

	private Channels[] testData;

	/*
	 * fillTestData() Add data into H2 database(virtual database for whitebox
	 * testing)
	 */

	@BeforeEach
	public void fillTestData() {
		testData = new Channels[] { new Channels(101, "AajTak", "Hindi", "News", 330.0),
				new Channels(102, "Colors", "Hindi", "Movies", 230.0),
				new Channels(103, "SetMax", "Kannada", "Movies", 130.0),
				new Channels(104, "MajhaMaha", "Marathi", "Serials", 100.0) };

		for (Channels channels : testData) {
			entityManager.persist(channels);
		}
		entityManager.flush();
	}

	/*
	 * clearDatabase() clear all data from H2 database after testing is done
	 */

	@AfterEach
	public void clearDatabase() {
		for (Channels channels : testData) {
			entityManager.remove(channels);
		}
		entityManager.flush();
	}

	/*
	 * findByNameTest() tests find operation with respect to Name
	 */
	@Test
	public void findByNameTest() {
		for (Channels channels : testData) {
			Assertions.assertEquals(channels, channelRepository.findByName(channels.getName()));
		}
	}

	/*
	 * findByNameTestWithNonExistingDate() tests find operation with with non
	 * existing Name
	 */
	@Test
	public void findByNameTestWithNonExistingDate() {
		Assertions.assertNull(channelRepository.findByName("@#1234"));
	}

	/*
	 * findByLanguageTest() test find operation with respect to language
	 */
	@Test
	public void findByLanguageTest() {
		for (Channels channels : testData) {
			Assertions.assertEquals(channels, channelRepository.findByLanguage(channels.getLanguage()));
		}
	}

	/*
	 * findByLanguageTestWithNonExistingDate() tests find operation with with non
	 * existing Language
	 */

	@Test
	public void findByLanguageTestWithNonExistingDate() {
		Assertions.assertNull(channelRepository.findByLanguage("%^@#"));
	}

	/*
	 * findByCategoryTest() test find operation with the help of Category
	 */
	@Test
	public void findByCategoryTest() {
		for (Channels channels : testData) {
			Assertions.assertEquals(channels, channelRepository.findByCategory(channels.getCategory()));
		}
	}

	/*
	 * findByCategoryTestWithNonExistingDate() tests find operation with with non
	 * existing Category
	 */
	@Test
	public void findByCategoryTestWithNonExistingDate() {
		Assertions.assertNull(channelRepository.findByCategory("87!@##"));
	}
}
