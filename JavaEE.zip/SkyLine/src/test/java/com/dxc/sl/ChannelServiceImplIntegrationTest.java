package com.dxc.sl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import com.dxc.sl.entity.Channels;
import com.dxc.sl.exception.ChannelException;
import com.dxc.sl.repository.ChannelRepository;
import com.dxc.sl.service.ChannelService;

@SpringJUnitConfig
@SpringBootTest
@TestPropertySource(locations = "classpath:application-test.properties")

public class ChannelServiceImplIntegrationTest {

	@Autowired
	private ChannelRepository repository;

	@Autowired
	private ChannelService channelService;

	private Channels[] testData;

	/*
	 * fillTestData() Add data into H2 database(virtual database for whitebox
	 * testing)
	 */

	@BeforeEach
	public void fillTestData() {
		testData = new Channels[] { new Channels(101, "AajTak", "Hindi", "News", 330.0),
				new Channels(102, "Colors", "Hindi", "Movies", 230.0),
				new Channels(103, "SetMax", "Kannada", "Movies", 130.0),
				new Channels(104, "MajhaMaharashtra", "Marathi", "Serials", 100.0), };
		for (Channels channel : testData) {
			repository.saveAndFlush(channel);
		}
	}

	/*
	 * clearDatabase() clear all data from H2 database after testing is done
	 */

	@AfterEach
	public void clearDatabase() {
		repository.deleteAll();
		testData = null;
	}

	/*
	 * addTest() test addititon operation
	 */

	@Test
	public void addTest() {
		try {
			Channels expected = new Channels(106, "KannadaMo", "Kannada", "movies", 400.0);
			Channels actual = channelService.add(expected);
			Assertions.assertEquals(expected, actual);

		} catch (ChannelException e) {
			Assertions.fail(e.getMessage());
		}
	}

	/*
	 * addExistingChannelTest() test addititon operation with existing id
	 */

	@Test
	public void addExistingChannelTest() {
		Assertions.assertThrows(ChannelException.class, () -> {
			channelService.add(testData[0]);
		});
	}

	/*
	 * deleteByIdExistingRecordTest() tests delete operation with existing Id
	 */

	@Test
	public void deleteByIdExistingChannelTest() {
		try {
			Assertions.assertTrue(channelService.deleteById(testData[1].getChannel_id()));
		} catch (ChannelException e) {
			Assertions.fail(e.getLocalizedMessage());
		}
	}

	/*
	 * deleteByIdNonExistingRecordTest() tests delete operation with Non existing Id
	 */

	@Test
	public void deleteByIdNonExistingChannelTest() {
		Assertions.assertThrows(ChannelException.class, () -> {
			channelService.deleteById(134);
		});
	}

	/*
	 * getAllChannelsWhenDataExists() tests get all operation with existing data
	 */

	@Test
	public void getAllChannelsWhenDataExists() throws ChannelException {
		List<Channels> expected = Arrays.asList(testData);
		Assertions.assertIterableEquals(expected, channelService.getAllChannels());
	}

	/*
	 * getAllChannelsWhenDataNotExists() tests get all operation with non existing
	 * data
	 */

	@Test
	public void getAllChannelssWhenNoDataExists() throws ChannelException {
		List<Channels> expected = new ArrayList<>();
		repository.deleteAll();
		Assertions.assertEquals(expected, channelService.getAllChannels());
	}

}
