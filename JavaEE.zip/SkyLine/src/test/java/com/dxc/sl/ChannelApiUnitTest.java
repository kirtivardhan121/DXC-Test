package com.dxc.sl;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;
import org.springframework.test.web.servlet.MockMvc;

import com.dxc.sl.api.ChannelApi;
import com.dxc.sl.entity.Channels;
import com.dxc.sl.exception.ChannelException;
import com.dxc.sl.service.ChannelService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;

@SpringJUnitConfig
@WebMvcTest(ChannelApi.class)
public class ChannelApiUnitTest {

	@Autowired
	private MockMvc mvcClient;

	@MockBean
	private ChannelService channelService;

	private List<Channels> testData;

	private static final String API_URL = "/channels";

	/*
	 * fillTestData() Add data into H2 database(virtual database for whitebox
	 * testing)
	 */

	@BeforeEach
	public void fillTestData() {

		testData = new ArrayList<>();
		testData.add(new Channels(101, "AajTak", "Hindi", "News", 330.0));
		testData.add(new Channels(102, "Colors", "Hindi", "Movies", 230.0));
		testData.add(new Channels(103, "SetMax", "Kannada", "Movies", 130.0));
		testData.add(new Channels(104, "MajhaMaharashtra", "Marathi", "Serials", 100.0));

	}

	/*
	 * clearDatabase() clear all data from H2 database after testing is done
	 */

	@AfterEach
	public void clearDatabase() {
		testData = null;
	}

	/*
	 * getAllChannelsWhenDataExists() tests get all operation with existing data
	 */
	@Test
	public void getAllChannels() throws ChannelException {

		Mockito.when(channelService.getAllChannels()).thenReturn(testData);

		try {
			mvcClient.perform(get(API_URL)).andExpect(status().isOk()).andExpect(jsonPath("$", hasSize(4)))
					.andDo(print());
		} catch (Exception e) {
			Assertions.fail(e.getMessage());
		}
	}

	/*
	 * getChannelByIdTest() tests getById operation with existing Id
	 */
	@Test
	public void getChannelByIdTest() throws ChannelException {
		Channels testRec = testData.get(0);

		Mockito.when(channelService.getById(testRec.getChannel_id())).thenReturn(testRec);

		try {
			mvcClient.perform(get(API_URL + "/" + testRec.getChannel_id())).andExpect(status().isOk())
					.andExpect(jsonPath("$.name", is(testRec.getName())))
					.andExpect(jsonPath("$.language", is(testRec.getLanguage()))).andDo(print());
		} catch (Exception e) {
			Assertions.fail(e.getMessage());
		}

	}

	/*
	 * getChannelByIdTestNonExisting() tests getById operation with non existing Id
	 */

	@Test
	public void getChannelByIdTestNonExisting() throws ChannelException {

		Mockito.when(channelService.getById(8888)).thenReturn(null);

		try {
			mvcClient.perform(get(API_URL + "/9999")).andExpect(status().isNotFound()).andDo(print());
		} catch (Exception e) {
			Assertions.fail(e.getMessage());
		}

	}

	private static final ObjectMapper makeMapper() {
		ObjectMapper mapper = new ObjectMapper();
		mapper.registerModule(new ParameterNamesModule());
		mapper.registerModule(new Jdk8Module());
		mapper.registerModule(new JavaTimeModule());
		return mapper;
	}

	/*
	 * createChannelTest() tests create operation with non valid data
	 */

	@Test
	public void createChannelTest() {
		Channels testRec = testData.get(0);

		try {
			Mockito.when(channelService.add(testRec)).thenReturn(testRec);

			mvcClient
					.perform(post(API_URL).contentType(MediaType.APPLICATION_JSON)
							.content(makeMapper().writeValueAsString(testRec)))
					.andExpect(status().isOk()).andDo(print());
		} catch (Exception e) {
			Assertions.fail(e.getMessage());
		}

	}

	/*
	 * deleteChannelByIdTest() tests delete operation with existing id
	 */
	@Test
	public void deleteChannelByIdTest() {

		try {
			Mockito.when(channelService.deleteById(testData.get(0).getChannel_id())).thenReturn(true);

			mvcClient.perform(delete(API_URL + "/" + testData.get(0).getChannel_id())).andExpect(status().isOk())
					.andDo(print());
		} catch (Exception e) {
			Assertions.fail(e.getMessage());
		}
	}

	/*
	 * getChannelBylanguageTest() tests get operation with existing laguage
	 */
	@Test
	public void getChannelBylanguageTest() throws ChannelException {
		Channels testRec = testData.get(0);

		Mockito.when(channelService.findByLanguage(testRec.getLanguage())).thenReturn(testData);

		try {
			mvcClient.perform(get(API_URL + "/language" + "/" + testRec.getLanguage())).andExpect(status().isOk())
					.andExpect(jsonPath("$", hasSize(4))).andDo(print());
		} catch (Exception e) {
			Assertions.fail(e.getMessage());
		}
	}

	/*
	 * getChannelByCategoryTest() tests get operation with existing category
	 */

	@Test
	public void getChannelByCategoryTest() throws ChannelException {
		Channels testRec = testData.get(0);

		Mockito.when(channelService.findByCategory(testRec.getCategory())).thenReturn(testData);

		try {
			mvcClient.perform(get(API_URL + "/category" + "/" + testRec.getCategory())).andExpect(status().isOk())
					.andExpect(jsonPath("$", hasSize(4))).andDo(print());
		} catch (Exception e) {
			Assertions.fail(e.getMessage());
		}
	}
}
