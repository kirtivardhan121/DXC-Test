package com.dxc.sl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import com.dxc.sl.entity.Channels;
import com.dxc.sl.exception.ChannelException;
import com.dxc.sl.repository.ChannelRepository;
import com.dxc.sl.service.ChannelService;
import com.dxc.sl.service.ChannelServiceImpl;

@SpringJUnitConfig
public class ChannelServiceImplUnitTest {

	@MockBean
	private ChannelRepository channelRepo;

	@TestConfiguration
	static class ChannelServiceImplTestContextConfiguration {

		@Bean
		public ChannelService channelService() {
			return new ChannelServiceImpl();
		}
	}

	@Autowired
	private ChannelService channelService;

	private Channels[] testData;

	/*
	 * fillTestData() Add data into H2 database(virtual database for whitebox
	 * testing)
	 */
	@BeforeEach
	public void fillTestData() {
		testData = new Channels[] { new Channels(101, "AajTak", "Hindi", "News", 330.0),
				new Channels(102, "Colors", "Hindi", "Movies", 230.0),
				new Channels(103, "SetMax", "Kannada", "Movies", 130.0),
				new Channels(104, "MajhaMaharashtra", "Marathi", "Serials", 100.0) };
	}

	/*
	 * clearDatabase() clear all data from H2 database after testing is done
	 */
	@AfterEach
	public void clearDatabase() {
		testData = null;
	}

	/*
	 * addTest() test addititon operation
	 */
	@Test
	public void addTest() {
		Mockito.when(channelRepo.save(Mockito.any(Channels.class))).thenReturn(null);

		Mockito.when(channelRepo.existsById(testData[0].getChannel_id())).thenReturn(false);

		try {
			Channels actual = channelService.add(testData[0]);
			Assertions.assertEquals(testData[0], actual);
		} catch (ChannelException e) {
			Assertions.fail(e.getMessage());
		}

	}

	/*
	 * addExistingChannelTest() test addititon operation with existing id
	 */

	@Test
	public void addExistingChannelTest() {
		Mockito.when(channelRepo.save(Mockito.any(Channels.class))).thenReturn(null);

		Mockito.when(channelRepo.existsById(testData[0].getChannel_id())).thenReturn(true);

		Assertions.assertThrows(ChannelException.class, () -> {
			channelService.add(testData[0]);
		});

	}

	/*
	 * deleteByIdExistingRecordTest() tests delete operation with existing Id
	 */
	@Test
	public void deleteByIdExistingRecordTest() {
		Mockito.when(channelRepo.existsById(Mockito.isA(Integer.class))).thenReturn(true);

		Mockito.doNothing().when(channelRepo).deleteById(Mockito.isA(Integer.class));

		try {
			Assertions.assertTrue(channelService.deleteById(testData[0].getChannel_id()));
		} catch (ChannelException e) {
			Assertions.fail(e.getLocalizedMessage());
		}
	}

	/*
	 * deleteByIdNonExistingRecordTest() tests delete operation with Non existing Id
	 */
	@Test
	public void deleteByIdNonExistingRecordTest() {

		Mockito.when(channelRepo.existsById(Mockito.isA(Integer.class))).thenReturn(false);

		Mockito.doNothing().when(channelRepo).deleteById(Mockito.isA(Integer.class));

		Assertions.assertThrows(ChannelException.class, () -> {
			channelService.deleteById(testData[0].getChannel_id());
		});
	}
	/*
	 * getByIdExistingRecordTest() tests get operation with existing Id
	 */

	@Test
	public void getByIdExistingRecordTest() {
		Mockito.when(channelRepo.findById(testData[0].getChannel_id())).thenReturn(Optional.of(testData[0]));

		try {
			Assertions.assertEquals(testData[0], channelService.getById(testData[0].getChannel_id()));
		} catch (ChannelException e) {
			Assertions.fail(e.getLocalizedMessage());
		}
	}

	/*
	 * getByIdNonExistingRecordTest() tests get operation with non existing Id
	 */

	@Test
	public void getByIdNonExistingRecordTest() {
		Mockito.when(channelRepo.findById(testData[0].getChannel_id())).thenReturn(Optional.empty());

		try {
			Assertions.assertNull(channelService.getById(testData[0].getChannel_id()));
		} catch (ChannelException e) {
			Assertions.fail(e.getLocalizedMessage());
		}

	}

	/*
	 * getAllChannelsWhenDataExists() tests get all operation with existing data
	 */

	@Test
	public void getAllChannelsWhenDataExists() {
		List<Channels> expected = Arrays.asList(testData);

		Mockito.when(channelRepo.findAll()).thenReturn(expected);

		try {
			Assertions.assertEquals(expected, channelService.getAllChannels());
		} catch (ChannelException e) {
			Assertions.fail(e.getLocalizedMessage());
		}
	}

	/*
	 * getAllChannelsWhenDataNotExists() tests get all operation with non existing
	 * data
	 */

	@Test
	public void getAllChannelsWhenDataNotExists() {
		List<Channels> expected = new ArrayList<>();

		Mockito.when(channelRepo.findAll()).thenReturn(expected);

		try {
			Assertions.assertEquals(expected, channelService.getAllChannels());
		} catch (ChannelException e) {
			Assertions.fail(e.getLocalizedMessage());
		}
	}
}
