package com.dxc.sl.exception;

public class ChannelException extends Exception{

	public ChannelException(String errMsg) {
		super(errMsg);
	}
}//end ofChannelException
