package com.dxc.sl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkyLineApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkyLineApplication.class, args);
	}

}
