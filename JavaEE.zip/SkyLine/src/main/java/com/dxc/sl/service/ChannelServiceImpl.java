package com.dxc.sl.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dxc.sl.entity.Channels;
import com.dxc.sl.exception.ChannelException;
import com.dxc.sl.repository.ChannelRepository;

@Service
public class ChannelServiceImpl implements ChannelService {

	@Autowired
	private ChannelRepository channelRepo;

	/*
	 * Add() checks all the possible validations if all the validations are pasesses
	 * it'll add in database and give success code as 200.
	 */
	@Transactional
	@Override
	public Channels add(Channels channels) throws ChannelException {

		if (channels != null) {
			if (channelRepo.existsById(channels.getChannel_id())) {
				throw new ChannelException("A Channel with channel id " + channels.getChannel_id() + " already exists");
			}
			channelRepo.save(channels);
		}
		return channels;
	}

	/*
	 * deleteById() checks if id is present or not, if id is present it'll delete
	 * data from databases and and give 200 as code otherwise 400.
	 */
	@Transactional
	@Override
	public boolean deleteById(int channel_id) throws ChannelException {
		boolean deleted = false;

		if (!channelRepo.existsById(channel_id)) {
			throw new ChannelException("No such channel found to delete!!");
		}
		channelRepo.deleteById(channel_id);
		return deleted;
	}

	/*
	 * getById() find the data with the help of channel id if id is not correct
	 * it'll throw 400 code otherwise 200
	 */
	@Transactional
	@Override
	public Channels getById(int channel_id) throws ChannelException {

		return channelRepo.findById(channel_id).orElse(null);

	}

	/*
	 * getAllChannels() retrive all data from database
	 */
	@Transactional
	@Override
	public List<Channels> getAllChannels() throws ChannelException {
		return channelRepo.findAll();
	}

	/*
	 * findByName() find the data based on Name and gives sucess code as 200
	 * otherwise 400
	 */
	@Override
	public Channels findByName(String name) throws ChannelException {

		return channelRepo.findByName(name);
	}

	/*
	 * findByCategory() find the data based on Category and gives sucess code as 200
	 * otherwise 400
	 */

	@Override
	public List<Channels> findByCategory(String category) throws ChannelException {
		return channelRepo.findByCategory(category);
	}

	/*
	 * findByLanguage() find the data based on Language and gives sucess code as 200
	 * otherwise 400
	 */

	@Override
	public List<Channels> findByLanguage(String language) throws ChannelException {
		return channelRepo.findByLanguage(language);
	}

}// end of ChannelServiceImpl
