package com.dxc.sl.service;

import java.util.List;

import com.dxc.sl.entity.Channels;
import com.dxc.sl.exception.ChannelException;

public interface ChannelService {

	Channels add(Channels channels) throws ChannelException;

	boolean deleteById(int channel_id) throws ChannelException;

	Channels getById(int channel_id) throws ChannelException;

	List<Channels> getAllChannels() throws ChannelException;

	Channels findByName(String name) throws ChannelException;

	List<Channels> findByCategory(String category) throws ChannelException;

	List<Channels> findByLanguage(String language) throws ChannelException;
}//end of ChannelService
