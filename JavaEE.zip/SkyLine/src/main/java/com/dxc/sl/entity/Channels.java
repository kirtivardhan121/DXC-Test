package com.dxc.sl.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "channels")
public class Channels implements Serializable {

	@Id
	@Column(name = "channel_id")
	@NotNull(message = "Id can not be null")
	private Integer channel_id;

	@Column(name = "name")
	@NotBlank(message = "Name can not be blank")
	@Size(min = 4, max = 20, message = "Name must be of 4 to 20 characters in length")
	private String name;

	@Column(name = "language")
	@NotBlank(message = "Language can not be blank")
	@Size(min = 2, max = 10, message = "Language must be of 2 to 10 characters in length")
	private String language;

	@Column(name = "category")
	@NotBlank(message = "Category can not be blank")
	@Size(min = 2, max = 10, message = "Category must be of 2 to 10 characters in length")
	private String category;

	@Column(name = "subscription_fee")
	@NotNull(message = "Fee can not be blank")
	@Min(value = 20, message = "minimum fee is expected to be 20")
	@Max(value = 500, message = "maximum fee is expected not more than 500")
	private Double subscription_fee;

	public Channels() {
		// left Unimplemented
	}

	public Channels(@NotNull(message = "Id can not be null") Integer channel_id,
			@NotBlank(message = "Name can not be blank") @Size(min = 4, max = 20, message = "Name must be of 4 to 20 characters in length") String name,
			@NotBlank(message = "Language can not be blank") @Size(min = 2, max = 10, message = "Language must be of 2 to 10 characters in length") String language,
			@NotBlank(message = "Category can not be blank") @Size(min = 2, max = 10, message = "Category must be of 2 to 10 characters in length") String category,
			@NotNull(message = "Fee can not be blank") @Min(value = 20, message = "minimum fee is expected to be 20") @Max(value = 500, message = "maximum fee is expected not more than 500") Double subscription_fee) {
		super();
		this.channel_id = channel_id;
		this.name = name;
		this.language = language;
		this.category = category;
		this.subscription_fee = subscription_fee;
	}

	public Integer getChannel_id() {
		return channel_id;
	}

	public void setChannel_id(Integer channel_id) {
		this.channel_id = channel_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Double getSubscription_fee() {
		return subscription_fee;
	}

	public void setSubscription_fee(Double subscription_fee) {
		this.subscription_fee = subscription_fee;
	}

}//end of Channels
