package com.dxc.sl.api;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dxc.sl.entity.Channels;
import com.dxc.sl.exception.ChannelException;
import com.dxc.sl.service.ChannelService;

@RestController
@RequestMapping("/channels")
public class ChannelApi {

	@Autowired
	private ChannelService channelService;

	/*
	 * getAllChannels() retrive all data from database and give success code as 200
	 * otherwise failure code as 400 or 405
	 */
	@GetMapping
	public ResponseEntity<List<Channels>> getAllChannels() throws ChannelException {
		return new ResponseEntity<>(channelService.getAllChannels(), HttpStatus.OK);
	}

	/*
	 * getChannelById retrive data which matches with id given from database and
	 * give success code as 200 otherwise failure code as 404.
	 */

	@GetMapping("/{channel_id:[0-9]{1,5}}")
	public ResponseEntity<Channels> getChannelById(@PathVariable("channel_id") int channel_id) throws ChannelException {

		ResponseEntity<Channels> response = null;

		Channels channels = channelService.getById(channel_id);

		if (channels == null) {
			response = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} else {
			response = new ResponseEntity<>(channels, HttpStatus.OK);
		}

		return response;
	}

	/*
	 * createChannels() create channel and save it in database and give success code
	 * as 200 otherwise failure code as 400 or 405
	 */

	@PostMapping
	public ResponseEntity<Channels> createChannel(@Valid @RequestBody Channels channels, BindingResult result)
			throws ChannelException {
		ResponseEntity<Channels> response = null;

		if (result.hasErrors()) {
			StringBuilder errMsg = new StringBuilder();
			for (FieldError err : result.getFieldErrors()) {
				errMsg.append(err.getDefaultMessage() + ",");
			}
			throw new ChannelException(errMsg.toString());
		} else {
			channelService.add(channels);
			response = new ResponseEntity<>(channels, HttpStatus.OK);
		}

		return response;
	}

	/*
	 * deleteChannelById delete data which matches with id given from database and
	 * give success code as 200 otherwise failure code as 404.
	 */

	@DeleteMapping("/{channel_id}")
	public ResponseEntity<Void> deleteChannelById(@PathVariable("channel_id") int channel_id) throws ChannelException {
		channelService.deleteById(channel_id);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	/*
	 * getChannelByName retrive data which matches with Name given from database and
	 * give success code as 200 otherwise failure code as 404.
	 */

	@GetMapping("/name/{name:[A-Za-z]{4,20}}")
	public ResponseEntity<Channels> getChannelByName(@PathVariable("name") String name) throws ChannelException {
		ResponseEntity<Channels> response = null;

		Channels channels = channelService.findByName(name);

		if (channels == null) {
			response = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} else {
			response = new ResponseEntity<>(channels, HttpStatus.OK);
		}

		return response;
	}

	/*
	 * getChannelByCategory retrive all data which matches with category given from
	 * database and give success code as 200 otherwise failure code as 404.
	 */

	@GetMapping("/category/{category:[A-Za-z]{3,10}}")
	public ResponseEntity<List<Channels>> getChannelsByCategory(@PathVariable("category") String category)
			throws ChannelException {
		ResponseEntity<List<Channels>> response = null;

		List<Channels> channels = channelService.findByCategory(category);

		if (channels == null || channels.size() == 0) {
			response = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} else {
			response = new ResponseEntity<>(channels, HttpStatus.OK);
		}

		return response;
	}

	/*
	 * getChannelByLanguage retrive all data which matches with Language given from
	 * database and give success code as 200 otherwise failure code as 404.
	 */

	@GetMapping("/language/{language:[A-Za-z]{3,10}}")
	public ResponseEntity<List<Channels>> getChannelsByLanguage(@PathVariable("language") String language)
			throws ChannelException {
		ResponseEntity<List<Channels>> response = null;

		List<Channels> channels = channelService.findByLanguage(language);

		if (channels == null || channels.size() == 0) {
			response = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} else {
			response = new ResponseEntity<>(channels, HttpStatus.OK);
		}

		return response;
	}
}// end of ChannelApi
