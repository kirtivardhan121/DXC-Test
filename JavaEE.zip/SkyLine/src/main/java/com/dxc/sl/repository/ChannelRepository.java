package com.dxc.sl.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dxc.sl.entity.Channels;

@Repository
public interface ChannelRepository extends JpaRepository<Channels, Integer> {

	Channels findByName(String name);

	List<Channels> findByCategory(String category);

	List<Channels> findByLanguage(String language);
}//end of ChannelRepository
