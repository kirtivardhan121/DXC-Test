create table items (
	icode integer primary key, 
	pdate date not null, 
	price double not null, 
	title varchar(45) not null
);