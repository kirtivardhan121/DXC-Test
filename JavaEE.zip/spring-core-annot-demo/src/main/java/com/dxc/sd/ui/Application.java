package com.dxc.sd.ui;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.dxc.sd.config.MyConfig;
import com.dxc.sd.service.GreetService;
import com.dxc.sd.service.MultiLingualGreetingService;

public class Application {

	public static void main(String[] args) {
		
		ApplicationContext context = new AnnotationConfigApplicationContext(MyConfig.class);
	
		Scanner scan = (Scanner) context.getBean("kbScan");
		System.out.println("Enter Your name: ");
		String userName = scan.next();
		
		GreetService gs1 = (GreetService) context.getBean("gs");
		System.out.println(gs1.getGreeting(userName));
		
		GreetService gs2 = (GreetService) context.getBean("gs2");
		System.out.println(gs2.getGreeting(userName));
		
		MultiLingualGreetingService mgs = (MultiLingualGreetingService)context.getBean("mgs");
		for(String g:mgs.getAllGreets(userName)) {
			System.out.println(g);
		}
	}
}
