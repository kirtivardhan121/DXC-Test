package com.dxc.sd.service;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

@Service("gnp2")
//@Primary
public class GreetNoteProviderSimpleImpl implements GreetNoteProvider{

	public String getGreetNote() {
		
		return "Hello!";
	}

}
