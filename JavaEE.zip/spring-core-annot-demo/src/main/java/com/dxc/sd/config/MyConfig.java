package com.dxc.sd.config;

import java.time.LocalDateTime;
import java.util.Scanner;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@ComponentScan(basePackages = {"com.dxc.sd"})
@PropertySource({"classpath:myProps.properties"})
public class MyConfig {

	@Bean
	public Scanner kbScan() {
		return new Scanner(System.in);
	}
	
	@Bean
	public LocalDateTime today() {
		return LocalDateTime.now();
	}
}
