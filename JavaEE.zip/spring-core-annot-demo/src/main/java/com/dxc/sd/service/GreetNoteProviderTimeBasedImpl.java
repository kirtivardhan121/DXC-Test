package com.dxc.sd.service;

import java.time.LocalDateTime;
import java.time.LocalTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

@Service("gnp1")
//@Primary
public class GreetNoteProviderTimeBasedImpl implements GreetNoteProvider {

	@Autowired
	private LocalDateTime today;
	
	public String getGreetNote() {
		String greetNote = null;
		
		int h = today.getHour();
		
		if(h>=4 && h<=4) {
			greetNote = "Good Morning";
		}else if(h>=11 && h<=17) {
			greetNote = "Good Noon";
		} else {
			greetNote = "Good Evening";
		}
		
		return greetNote;
	}

}
