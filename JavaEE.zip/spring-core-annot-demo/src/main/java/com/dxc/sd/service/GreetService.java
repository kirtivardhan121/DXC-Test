package com.dxc.sd.service;

public interface GreetService {

	public String getGreeting(String userName);
}
