package com.dxc.sd.service;

public interface GreetNoteProvider {

	String getGreetNote();
}
