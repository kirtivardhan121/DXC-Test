package com.dxc.sd.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service("mgs")
public class MultiLingualGreetingService {

	@Value("${greeting.greetings}")
	private String[] greetings;
	
	public String[] getAllGreets(String userName) {
		
		String[] greets = new String[greetings.length];
		
		for(int i=0;i<greetings.length;i++) {
			greets[i] = greetings[i]+" "+userName;
		}
		
		return greets;
	}
}
