package com.dxc.sd.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service("gs2")
public class GreetServiceAdvancedImpl implements GreetService {

	@Autowired
	@Qualifier("gnp1")
	private GreetNoteProvider gnProvider;
	
	public GreetServiceAdvancedImpl() {
		//left unimplemented
	}

	

	public GreetServiceAdvancedImpl(GreetNoteProvider gnProvider) {
		super();
		this.gnProvider = gnProvider;
	}


	

	public GreetNoteProvider getGnProvider() {
		return gnProvider;
	}



	public void setGnProvider(GreetNoteProvider gnProvider) {
		this.gnProvider = gnProvider;
	}



	public String getGreeting(String userName) {
		
		return gnProvider.getGreetNote() +" "+ userName;
	}

	public void onCreate() {
		System.out.println("Bean is created");
	}
	
	public void onDestroy() {
		System.out.println("Bean is destroyed");
	}
}
