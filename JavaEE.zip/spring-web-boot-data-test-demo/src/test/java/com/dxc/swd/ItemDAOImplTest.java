package com.dxc.swd;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import com.dxc.swd.entity.Item;
import com.dxc.swd.repository.ItemRepository;

//@RunWith(SpringRunner.class) // a bridge between Spring Boot test features and JUnit
@DataJpaTest // configuring H2, an in-memory database,setting Hibernate, Spring Data, and the
				// DataSource,performing an @EntityScan turning on SQL logging
public class ItemDAOImplTest {

	@Autowired
	private TestEntityManager entityManager;

	@Autowired
	private ItemRepository itemRepository;

	private Item[] testData;

	@BeforeEach
	public void fillTestData() {

		testData = new Item[] { new Item(101, "RiceOrPaddy", 690, LocalDate.now()),
				new Item(102, "Wheat", 990, LocalDate.now()), new Item(103, "Barley", 850, LocalDate.now()),
				new Item(104, "CocoSeed", 500, LocalDate.now()), new Item(105, "CoffeBean", 900, LocalDate.now()) };

		// inserting test data into H2 database
		for (Item item : testData) {
			entityManager.persist(item);
		}
		entityManager.flush();
	}

	@AfterEach
	public void clearDatabase() {
		// removing test data into H2 database
		for (Item item : testData) {
			entityManager.remove(item);
		}
		entityManager.flush();
	}

	@Test
	public void findByInameTest() {
		for (Item item : testData) {
			Assertions.assertEquals(item, itemRepository.findByIname(item.getIname()));
		}
	}

	@Test
	public void findByInameTestWithNonExistingDate() {
		Assertions.assertNull(itemRepository.findByIname("@#1234"));
	}

	@Test
	public void findAllByPackageDateTest() {
		Item[] actualData = itemRepository.findAllByPackageDate(LocalDate.now()).toArray(new Item[] {});
		for (int i = 0; i < actualData.length; i++) {
			Assertions.assertEquals(testData[i], actualData[i]);
		}
	}

	@Test
	public void findAllByPackageDateTestWithNonExistingDate() {
		List<Item> actualData = itemRepository.findAllByPackageDate(LocalDate.now().plusDays(2));
		Assertions.assertEquals(0, actualData.size());
	}

	@Test
	public void getAllInPriceRangeTest() {
		Item[] actualData = itemRepository.getAllInPriceRange(500, 1000).toArray(new Item[] {});
		Item[] expectedData = new Item[] { testData[1], testData[2] };

		for (int i = 0; i < actualData.length; i++) {
			Assertions.assertEquals(expectedData[i], actualData[i]);
		}
	}
}
