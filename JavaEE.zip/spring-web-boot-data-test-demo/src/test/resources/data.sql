create table items(
icode integer primary key, 
iname varchar(20) not null, 
pdate date not null, 
price double  not null
);