package com.dxc.scd.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dxc.scd.service.GreetService;
import com.dxc.scd.service.GreetServiceSimpleImpl;

public class Application1 {

	public static void main(String[] args) {
		
		//Constructor Injection
		
		GreetService gs = new GreetServiceSimpleImpl("Hello");
		System.out.println(gs.getGreeting("Kirtivardhan"));
		
		//Setter Injection
		
		GreetService gs2 = new GreetServiceSimpleImpl();
		((GreetServiceSimpleImpl)gs2).setGreetingNote("Hey!");
		System.out.println(gs2.getGreeting("Vardhan"));
		
		
		ApplicationContext context = new ClassPathXmlApplicationContext("beans1.xml");
		//Setter Injection using Spring IoC 
		
		GreetService gs3 = (GreetService) context.getBean("gsObj1");
		System.out.println(gs3.getGreeting("Kirtivardhan"));
		
		//Constructor Injection using Spring IoC
		
		GreetService gs4 = (GreetService) context.getBean("gsObj2");
		System.out.println(gs4.getGreeting("Kirtivardhan"));
	}
}
