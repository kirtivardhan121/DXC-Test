package com.dxc.scd.service;

public interface GreetService {

	public String getGreeting(String userName);
}
