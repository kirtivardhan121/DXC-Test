package com.dxc.scd.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dxc.scd.service.GreetService;

public class Application3 {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("beans3.xml");

		GreetService gs1 = (GreetService) context.getBean("gs1");
		System.out.println(gs1.getGreeting("vardhan"));

		GreetService gs2 = (GreetService) context.getBean("gs");
		System.out.println(gs2.getGreeting("Kirtivardhan"));

		GreetService gs3 = (GreetService) context.getBean("gs3");
		System.out.println(gs3.getGreeting("Kirti"));

		/*
		 * GreetService gs4 = (GreetService) context.getBean("gs4");
		 * System.out.println(gs4.getGreeting("Kirti"));
		 */

	}
}
