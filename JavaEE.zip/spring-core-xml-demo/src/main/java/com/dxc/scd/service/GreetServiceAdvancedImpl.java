package com.dxc.scd.service;

public class GreetServiceAdvancedImpl implements GreetService {

	private GreetNoteProvider gnProvider;
	
	public GreetServiceAdvancedImpl() {
		//left unimplemented
	}

	

	public GreetServiceAdvancedImpl(GreetNoteProvider gnProvider) {
		super();
		this.gnProvider = gnProvider;
	}


	

	public GreetNoteProvider getGnProvider() {
		return gnProvider;
	}



	public void setGnProvider(GreetNoteProvider gnProvider) {
		this.gnProvider = gnProvider;
	}



	public String getGreeting(String userName) {
		
		return gnProvider.getGreetNote() +" "+ userName;
	}

	public void onCreate() {
		System.out.println("Bean is created");
	}
	
	public void onDestroy() {
		System.out.println("Bean is destroyed");
	}
}
