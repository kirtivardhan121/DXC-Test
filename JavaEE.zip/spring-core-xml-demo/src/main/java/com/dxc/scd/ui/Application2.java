package com.dxc.scd.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dxc.scd.service.GreetService;
import com.dxc.scd.service.GreetServiceSimpleImpl;

public class Application2 {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("beans1.xml");
		//Setter Injection using Spring IoC 
		
		GreetService gs1 = (GreetService) context.getBean("gsObj1");
		System.out.println(gs1.getGreeting("Kirtivardhan"));
		
		((GreetServiceSimpleImpl)gs1).setGreetingNote("Hello");
		System.out.println(gs1.getGreeting("Vardhan"));
		
		GreetService gs2 = (GreetService) context.getBean("gsObj1");
		System.out.println(gs2.getGreeting("Kirtivardhan"));
		
	}
}
