package com.dxc.scd.service;

public class GreetNoteProviderSimpleImpl implements GreetNoteProvider{

	public String getGreetNote() {
		
		return "Hello!";
	}

}
