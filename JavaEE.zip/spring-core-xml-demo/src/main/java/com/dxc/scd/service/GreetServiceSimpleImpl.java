package com.dxc.scd.service;

public class GreetServiceSimpleImpl implements GreetService {

	private String greetingNote;
	
	public GreetServiceSimpleImpl() {
		// left unimplemented
	}
	
	
	
	public GreetServiceSimpleImpl(String greetingNote) {
		super();
		this.greetingNote = greetingNote;
	}

	

	public String getGreetingNote() {
		return greetingNote;
	}



	public void setGreetingNote(String greetingNote) {
		this.greetingNote = greetingNote;
	}



	public String getGreeting(String userName) {
		
		return greetingNote +" "+userName;
	}

	public void onCreate() {
		System.out.println("Bean is created");
	}
	
	public void onDestroy() {
		System.out.println("Bean is destroyed");
	}
}
