package com.dxc.scd.service;

public interface GreetNoteProvider {

	String getGreetNote();
}
