package com.dxc.sjmd.model;

import java.time.LocalDate;
import java.util.List;

public class EMILoanModel {

	private double loanAmount;
	private double annualInterestRate;
	private double emiCount;
	private LocalDate firstEmiDate;
	private List<EMIModel> emis;
	
	public EMILoanModel() {
		//left unimplemented
	}

	public double getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}

	public double getAnnualInterestRate() {
		return annualInterestRate;
	}

	public void setAnnualInterestRate(double annualInterestRate) {
		this.annualInterestRate = annualInterestRate;
	}

	public double getEmiCount() {
		return emiCount;
	}

	public void setEmiCount(double emiCount) {
		this.emiCount = emiCount;
	}

	public LocalDate getFirstEmiDate() {
		return firstEmiDate;
	}

	public void setFirstEmiDate(LocalDate firstEmiDate) {
		this.firstEmiDate = firstEmiDate;
	}

	public List<EMIModel> getEmis() {
		return emis;
	}

	public void setEmis(List<EMIModel> emis) {
		this.emis = emis;
	}
	
	
}
