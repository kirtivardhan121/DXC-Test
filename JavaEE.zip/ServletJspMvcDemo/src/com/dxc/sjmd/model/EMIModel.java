package com.dxc.sjmd.model;

import java.time.LocalDate;

public class EMIModel {

	private int emiNumber;
	private double emi;
	private LocalDate dueDate;
	private double principalComponent;
	private double interestComponent;
	
	public EMIModel() {
		//Left unimplemented
	}

	public EMIModel(int emiNumber, double emi, LocalDate dueDate, double principalComponent, double interestComponent) {
		super();
		this.emiNumber = emiNumber;
		this.emi = emi;
		this.dueDate = dueDate;
		this.principalComponent = principalComponent;
		this.interestComponent = interestComponent;
	}

	public int getEmiNumber() {
		return emiNumber;
	}

	public void setEmiNumber(int emiNumber) {
		this.emiNumber = emiNumber;
	}

	public double getEmi() {
		return emi;
	}

	public void setEmi(double emi) {
		this.emi = emi;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}

	public double getPrincipalComponent() {
		return principalComponent;
	}

	public void setPrincipalComponent(double principalComponent) {
		this.principalComponent = principalComponent;
	}

	public double getInterestComponent() {
		return interestComponent;
	}

	public void setInterestComponent(double interestComponent) {
		this.interestComponent = interestComponent;
	}
	
	
}
