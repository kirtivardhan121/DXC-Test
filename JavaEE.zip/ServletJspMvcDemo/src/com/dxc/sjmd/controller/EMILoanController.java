package com.dxc.sjmd.controller;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dxc.sjmd.model.EMILoanModel;
import com.dxc.sjmd.service.EMILoanService;

/**
 * Servlet implementation class EMILoanController
 */
@WebServlet("/emiCalc")
public class EMILoanController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public EMILoanController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		EMILoanService emiLoanService = new EMILoanService();

		String p = request.getParameter("p");
		String t = request.getParameter("t");
		String r = request.getParameter("r");

		String view = null;

		if(p==null || t==null || r==null) {
			view = "/EMILoanInputPage.jsp";
		}else {
			EMILoanModel model = new EMILoanModel();

			model.setAnnualInterestRate(Double.parseDouble(r));
			model.setLoanAmount(Double.parseDouble(p));
			model.setEmiCount(Double.parseDouble(t));
			model.setFirstEmiDate(LocalDate.parse(request.getParameter("fed")));

			emiLoanService.computeEMIs(model);

			request.setAttribute("loanModel", model);
			view = "/EMILoanOutputPage.jsp";
		}
		request.getRequestDispatcher(view).forward(request, response); 
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
