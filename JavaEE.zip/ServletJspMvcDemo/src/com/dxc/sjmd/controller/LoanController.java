package com.dxc.sjmd.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dxc.sjmd.model.LoanModel;
import com.dxc.sjmd.service.LoanService;

/**
 * Servlet implementation class LoanController
 */
@WebServlet("/loan")
public class LoanController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoanController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		LoanService loanService = new LoanService();
		
		String p = request.getParameter("p");
		String t = request.getParameter("t");
		String r = request.getParameter("r");
		
		String view = null;
		
		if(p==null || t==null || r==null) {
			view = "LoanInputPage.jsp";
		}else {
			LoanModel loanModel = new LoanModel();
			loanModel.setPrincipal(Double.parseDouble(p));
			loanModel.setTimePeriod(Double.parseDouble(t));
			loanModel.setRateOfInterest(Double.parseDouble(r));
			
			
			loanService.computeInterest(loanModel);
			loanService.computePayableAmount(loanModel);
			
			request.setAttribute("loanModel", loanModel);
			view = "/LoanOutputPage.jsp";
		}
		
		request.getRequestDispatcher(view).forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
