package com.dxc.sjmd.service;

import com.dxc.sjmd.model.LoanModel;

public class LoanService {

	public void computeInterest(LoanModel loan) {
		
		if(loan != null) {
			loan.setPayableAmount((loan.getPrincipal()*loan.getRateOfInterest()*loan.getTimePeriod())/100);
		}
	}
	
	public void computePayableAmount(LoanModel loan) {
		if(loan!=null) {
			loan.setPayableAmount(loan.getPrincipal()+loan.getInterest());
		}
	}
}
