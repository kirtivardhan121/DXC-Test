package com.dxc.sjmd.service;

import java.util.ArrayList;
import java.util.List;

import com.dxc.sjmd.model.EMILoanModel;
import com.dxc.sjmd.model.EMIModel;

public class EMILoanService {

	public void computeEMIs(EMILoanModel elModel) {
		if(elModel !=null) {

			double p = elModel.getLoanAmount();
			double r = elModel.getAnnualInterestRate();
			double N = elModel.getEmiCount();

			double emiAmount = p * r * (((1+r) *N)/(((1 + r ) * N) -1));

			List<EMIModel> emis = new ArrayList<>();

			for(int n=1;n<=N;n++) {
				EMIModel emi = new EMIModel();

				emi.setEmiNumber(n);
				emi.setDueDate(elModel.getFirstEmiDate().plusMonths(n-1));
				emi.setEmi(emiAmount);
				emi.setPrincipalComponent(Math.pow(1.0/(1+r/12.0), (N-n+1))*emiAmount); // {1 � (1+ R/12)}^(N- n+1) X EMI
				emi.setInterestComponent(emiAmount-emi.getPrincipalComponent());

				emis.add(emi);
			}

			elModel.setEmis(emis);

		}
	}
}
