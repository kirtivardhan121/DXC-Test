package com.dxc.sjmd.service;

import java.time.LocalTime;

public class GreetService {

	public String getGreeting() {
		String greeting = null;
		int hour = LocalTime.now().getHour();
		
		if(hour >=2 && hour <=11) {
			greeting = "Good Morning";
		}else if(hour >=12 && hour <=16) {
			greeting = "Good Noon";
		}else {
			greeting = "Good Evening";
		}
		return greeting;
	}
}
