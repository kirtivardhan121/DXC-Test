package com.dxc.swd.entity;

public class AppUser {

	private Long userId;
	private String userName;
	private String encryptedPassword;
	private boolean enabled;
	private String[] roles;

	public AppUser() {
		// TODO Auto-generated constructor stub
	}

	public AppUser(Long userId, String userName, String encryptedPassword, boolean enabled, String[] roles) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.encryptedPassword = encryptedPassword;
		this.enabled = enabled;
		this.roles = roles;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEncryptedPassword() {
		return encryptedPassword;
	}

	public void setEncryptedPassword(String encryptedPassword) {
		this.encryptedPassword = encryptedPassword;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public String[] getRoles() {
		return roles;
	}

	public void setRoles(String[] roles) {
		this.roles = roles;
	}

}
